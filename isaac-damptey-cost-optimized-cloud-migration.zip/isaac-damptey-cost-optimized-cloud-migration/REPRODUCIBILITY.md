# Independent reproduction instructions

1. Download/clone the source repository; unzip if necessary.
2. Use Python 3.10.13 where possible (other versions require fresh verification).
3. Install: `python -m pip install -r requirements.txt && python -m pip install -e .`.
4. Execute: `python scripts/reproduce_all.py`.
5. Review `outputs/validation/validation_results.csv` and `docs/VALIDATION_REPORT.md`.
6. Review `outputs/raw/monthly_costs_thesis_faithful.csv`, tables and figures.
7. Execute: `python -m pytest -q`.
8. Review `docs/UNRESOLVED_PARAMETERS.md` before making any claim about an independently generated first-principles result.

**Expected status**: thesis-faithful reconstruction PASS; first-principles scenario simulation **BLOCKED**, because required coefficients are not present in the final research artefacts. The strict execution entry point returns a nonzero status with the missing field list.

The existing `validation/thesis_validation.xlsx` is a formula-based independent arithmetic workbook. The script audits its formula cells but does not assert that headless Python recalculated the workbook in Microsoft Excel.

No random seed is needed because the thesis report uses deterministic analytical construction. Software-only scalability tests use explicitly labelled synthetic workload replication and must not be confused with the five-workload thesis evaluation.

The `legacy/appendix_a_transcribed.py` file preserves the thesis-provided code source as document-transcribed text, not a certified original author-created `.py` file. See `docs/SOURCE_PROVENANCE.md`.
