from cloud_migration.metrics import tco

def test_tco_is_sum():
    assert tco([1,2,3])==6
