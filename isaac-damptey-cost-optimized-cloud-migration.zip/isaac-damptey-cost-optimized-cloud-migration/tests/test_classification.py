import pandas as pd
import pytest
from cloud_migration.classification import normalised_resource_scores,classify_scores
from cloud_migration.exceptions import ParameterResolutionError

def test_normalised_scores_for_thesis_workload_shape():
    df=pd.DataFrame({"workload_id":["A","B"],"cpu_vcpu":[10,20],"storage_gb":[100,50],"network_gb_month":[25,50]})
    s=normalised_resource_scores(df)
    assert s.loc[s.workload_id=="B","x_cpu"].iloc[0]==1
    assert s.loc[s.workload_id=="A","x_sto"].iloc[0]==1
    assert s.loc[s.workload_id=="B","x_net"].iloc[0]==1

def test_classification_requires_documented_thresholds():
    with pytest.raises(ParameterResolutionError): classify_scores(1,0.2,0.3,None)

def test_classification_function_with_test_only_thresholds():
    assert classify_scores(0.9,0.2,0.2,{"compute":0.8,"storage":0.8,"network":0.8})=="compute-intensive"
