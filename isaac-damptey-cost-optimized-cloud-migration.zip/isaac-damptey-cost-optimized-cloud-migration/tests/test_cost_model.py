from cloud_migration.cost_model import compute_memory_cost,storage_cost,network_cost,backup_cost,aggregate_cost

def test_component_costs_and_aggregation():
    c=compute_memory_cost(2,4,0.05,0.01,730)
    assert round(c,2)==102.20
    s=storage_cost(1000,0.02); n=network_cost(100,0.08); b=backup_cost(500,0.01)
    assert (s,n,b)==(20.0,8.0,5.0)
    assert aggregate_cost(c,s,n,b)==c+s+n+b

def test_price_increase_cannot_reduce_cost():
    low=compute_memory_cost(2,4,0.05,0.01,730)
    high=compute_memory_cost(2,4,0.06,0.01,730)
    assert high>low
