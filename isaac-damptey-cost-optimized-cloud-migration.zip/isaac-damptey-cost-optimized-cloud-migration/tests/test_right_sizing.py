from cloud_migration.right_sizing import right_size

def test_right_sizing_never_underprovides():
    cpu,mem=right_size(10.1,20.1,0.10,0.10)
    assert cpu>=10.1 and mem>=20.1
    assert isinstance(cpu,int) and isinstance(mem,int)
