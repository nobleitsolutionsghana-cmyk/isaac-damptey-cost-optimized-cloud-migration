import pytest
from cloud_migration.cost_model import storage_cost
from cloud_migration.workload_model import storage_growth

def test_negative_cost_inputs_rejected():
    with pytest.raises(ValueError): storage_cost(-1,0.02)

def test_positive_storage_growth_does_not_reduce_storage():
    assert storage_growth(100,10,2)>storage_growth(100,10,1)
