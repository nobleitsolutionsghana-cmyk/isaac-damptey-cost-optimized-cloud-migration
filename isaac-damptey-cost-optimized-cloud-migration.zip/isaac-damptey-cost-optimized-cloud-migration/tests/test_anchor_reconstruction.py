from pathlib import Path
import pandas as pd
import numpy as np
from cloud_migration.reporting_reproduction import reconstruct_all
ROOT=Path(__file__).resolve().parents[1]

def test_all_anchor_constraints_and_tco():
    anchors=pd.read_csv(ROOT/"data/reference/scenario_anchors.csv"); monthly=reconstruct_all(anchors)
    for _,r in anchors.iterrows():
        s=r.scenario
        assert np.isclose(monthly.loc[0,s],r.month_1,atol=.01)
        assert np.isclose(monthly.loc[11,s],r.month_12,atol=.01)
        assert np.isclose(monthly.loc[23,s],r.month_24,atol=.01)
        assert np.isclose(monthly.loc[35,s],r.month_36,atol=.01)
        assert np.isclose(monthly[s].sum(),r.tco_usd,atol=.01)
