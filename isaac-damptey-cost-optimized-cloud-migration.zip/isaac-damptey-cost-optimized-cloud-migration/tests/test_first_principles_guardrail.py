from pathlib import Path
import pytest
from cloud_migration.simulation import run_first_principles
from cloud_migration.exceptions import ParameterResolutionError
ROOT=Path(__file__).resolve().parents[1]

def test_missing_thesis_parameters_are_not_imputed():
    with pytest.raises(ParameterResolutionError):
        run_first_principles(ROOT/"data/workloads.csv",ROOT/"data/pricing.csv",ROOT/"config/base.yaml",ROOT/"config/optimized.yaml")
