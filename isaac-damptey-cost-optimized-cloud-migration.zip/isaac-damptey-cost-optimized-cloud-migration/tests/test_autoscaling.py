from cloud_migration.autoscaling import utilisation,scaling_factor,autoscale_cpu

def test_autoscaling_equations():
    u=utilisation(9,10); assert u==0.9
    phi=scaling_factor(u,0.4,0.8,0.2,0.25); assert phi==1.25
    alloc=autoscale_cpu(9,phi,2,16); assert 2<=alloc<=16

def test_autoscaling_low_utilisation_scales_down_factor():
    assert scaling_factor(0.2,0.4,0.8,0.2,0.25)==0.8
