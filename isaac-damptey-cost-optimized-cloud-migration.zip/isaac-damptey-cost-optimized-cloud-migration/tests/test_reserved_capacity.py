from cloud_migration.reserved_capacity import effective_compute_cost

def test_reserved_discount_reduces_cost():
    assert effective_compute_cost(1000,0.5,0.2)==900
    assert effective_compute_cost(1000,0,0.5)==1000
