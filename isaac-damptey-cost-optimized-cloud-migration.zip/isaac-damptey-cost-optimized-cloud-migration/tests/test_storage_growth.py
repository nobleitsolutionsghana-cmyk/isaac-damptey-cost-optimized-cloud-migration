from cloud_migration.workload_model import storage_growth

def test_storage_growth_linear_and_monotonic():
    vals=[storage_growth(1000,50,m) for m in range(1,37)]
    assert vals[0]==1050
    assert all(b>a for a,b in zip(vals,vals[1:]))
