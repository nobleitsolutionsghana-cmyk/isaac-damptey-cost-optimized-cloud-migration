import math
from cloud_migration.workload_model import annual_to_monthly_rate,user_growth,compute_demand,memory_demand,network_demand

def test_annual_to_monthly_compound_conversion():
    m=annual_to_monthly_rate(0.05)
    assert math.isclose((1+m)**12,1.05,rel_tol=1e-12)

def test_demand_equations_direction():
    u=user_growth(1000,annual_to_monthly_rate(0.05),12)
    assert u>1000
    assert compute_demand(10,u,1000,0.5)>10
    assert memory_demand(20,u,1000,0.5)>20
    assert network_demand(100,u,1000,0.5)>100
