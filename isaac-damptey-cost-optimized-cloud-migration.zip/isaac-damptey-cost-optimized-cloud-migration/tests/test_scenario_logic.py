import pytest
from cloud_migration.scenarios import validate_scenario_parameters
from cloud_migration.exceptions import ParameterResolutionError

def test_incomplete_thesis_scenario_is_rejected():
    with pytest.raises(ParameterResolutionError):
        validate_scenario_parameters("optimized",{"rho_cpu":None})
