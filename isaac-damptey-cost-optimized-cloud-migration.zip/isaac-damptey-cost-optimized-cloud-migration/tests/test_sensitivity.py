from cloud_migration.sensitivity import uniform_pricing_sensitivity,percent_change

def test_uniform_pricing_cases():
    base=114549.88
    assert round(uniform_pricing_sensitivity(base,-.10),2)==103094.89
    assert round(uniform_pricing_sensitivity(base,.10),2)==126004.87
    assert round(percent_change(base,uniform_pricing_sensitivity(base,.10)),2)==10.00
