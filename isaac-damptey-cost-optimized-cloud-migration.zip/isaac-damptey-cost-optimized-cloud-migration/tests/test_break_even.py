from pathlib import Path
import pandas as pd
from cloud_migration.reporting_reproduction import reconstruct_all
from cloud_migration.break_even import break_even_month
ROOT=Path(__file__).resolve().parents[1]

def test_reported_break_even_months():
    monthly=reconstruct_all(pd.read_csv(ROOT/"data/reference/scenario_anchors.csv"))
    assert break_even_month(monthly.Baseline,monthly.Optimized,12000)==10
    assert break_even_month(monthly.Hybrid,monthly.Optimized,8000)==13
    assert break_even_month(monthly.Baseline,monthly.Hybrid,4500)==8
