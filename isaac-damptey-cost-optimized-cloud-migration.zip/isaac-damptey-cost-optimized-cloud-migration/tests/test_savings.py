from cloud_migration.metrics import savings_amount,savings_percent

def test_savings_math():
    assert savings_amount(70,100)==30
    assert savings_percent(70,100)==30
