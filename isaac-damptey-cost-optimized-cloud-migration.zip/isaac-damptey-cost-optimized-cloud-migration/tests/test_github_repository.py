from pathlib import Path
from cloud_migration.config import PROJECT_ROOT
from cloud_migration.reporting_reproduction import reconstruct_all
import pandas as pd


def test_github_entry_and_citation_exist():
    assert (PROJECT_ROOT/'scripts/reproduce_all.py').exists()
    assert (PROJECT_ROOT/'CITATION.cff').exists()
    assert (PROJECT_ROOT/'.github/workflows/tests.yml').exists()
    assert (PROJECT_ROOT/'legacy/appendix_a_transcribed.py').exists()


def test_reference_is_not_first_principles_input():
    # Reconstructed series explicitly consumes reported costs and 36-month TCO.
    anchors=pd.read_csv(PROJECT_ROOT/'data/reference/scenario_anchors.csv')
    monthly=reconstruct_all(anchors)
    assert abs(float(monthly['Optimized'].sum())-114549.88)<0.01
    assert (PROJECT_ROOT/'data/pricing.csv').exists()
