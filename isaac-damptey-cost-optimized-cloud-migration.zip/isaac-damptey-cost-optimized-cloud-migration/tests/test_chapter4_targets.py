from pathlib import Path
import pandas as pd
from cloud_migration.validation import build_validation_rows
ROOT=Path(__file__).resolve().parents[1]

def test_critical_thesis_faithful_targets_pass():
    v=build_validation_rows(ROOT/"data/reference")
    critical=v[v.reproduction_basis.str.contains("Exact thesis-faithful|Derived from reconstructed",regex=True)]
    # percentage rows tolerate thesis rounding; one-cent table display issue is documented separately
    assert (critical.status=="PASS").all()
