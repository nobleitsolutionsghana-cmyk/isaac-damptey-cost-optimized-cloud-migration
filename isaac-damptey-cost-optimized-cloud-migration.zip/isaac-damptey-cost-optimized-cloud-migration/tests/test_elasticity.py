from cloud_migration.elasticity import point_elasticity,average_elasticity

def test_point_elasticity_definition():
    assert point_elasticity(100,110,0.10)==1

def test_reported_average_elasticity_rounds_correctly():
    assert round(average_elasticity(5157.90,[5700.80,6246.17,6793.82],[.1,.2,.3]),3)==1.055
    assert round(average_elasticity(4452.17,[4888.06,5323.16,5757.54],[.1,.2,.3]),3)==0.978
    assert round(average_elasticity(3672.46,[4005.20,4335.22,4662.78],[.1,.2,.3]),3)==0.902
