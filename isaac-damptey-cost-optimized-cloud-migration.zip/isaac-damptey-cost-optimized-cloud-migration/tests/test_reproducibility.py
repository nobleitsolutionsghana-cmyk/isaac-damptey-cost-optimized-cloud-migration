from pathlib import Path
import pandas as pd
from cloud_migration.reporting_reproduction import reconstruct_all
ROOT=Path(__file__).resolve().parents[1]

def test_deterministic_rerun_identical():
    a=pd.read_csv(ROOT/"data/reference/scenario_anchors.csv")
    first=reconstruct_all(a); second=reconstruct_all(a)
    pd.testing.assert_frame_equal(first,second)
