# Appendix A provenance

`appendix_a_transcribed.py` is a **text transcription from the Python code printed in Appendix A of the supplied final thesis DOCX**, beginning with its `from pathlib import Path` line. It passed Python syntax parsing after transcription. This is NOT a version-control history or independently authenticated record of the original source files used during the study. It reproduces the thesis's stated reporting implementation, including tables and anchor-constrained series.

The modular `src/cloud_migration/` implementation was prepared **later** to make the published method auditable; it must not be represented as the exact historical development repository. See `docs/SOURCE_PROVENANCE.md`.

To run the Appendix A transcription in isolation: `cd legacy && python appendix_a_transcribed.py`. Output goes to `legacy/simulation_outputs/` (ignored by Git). The original script is preserved without silent methodological rewriting.
