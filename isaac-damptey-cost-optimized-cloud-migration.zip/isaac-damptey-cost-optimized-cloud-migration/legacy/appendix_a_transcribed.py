from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# 1. Output folder
# ---------------------------------------------------------------------------
OUTPUT_DIR = Path("simulation_outputs")
TABLE_DIR = OUTPUT_DIR / "tables"
FIGURE_DIR = OUTPUT_DIR / "figures"
TABLE_DIR.mkdir(parents=True, exist_ok=True)
FIGURE_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# 2. Simulation constants
# ---------------------------------------------------------------------------
HOURS_PER_MONTH = 730
SIMULATION_MONTHS = 36
MONTHS = np.arange(1, SIMULATION_MONTHS + 1)

# ---------------------------------------------------------------------------
# 3. Appendix B: sample input dataset / workload parameters
# ---------------------------------------------------------------------------
WORKLOADS = pd.DataFrame(
    [
        {
            "Workload": "LMS",
            "CPU_vCPU": 16,
            "Memory_GB": 64,
            "Storage_GB": 2000,
            "Network_GB_Month": 500,
            "Users": 5000,
            "Operational_Characterisation":
                "Interactive teaching platform with high access concurrency",
        },
        {
            "Workload": "SIS",
            "CPU_vCPU": 8,
            "Memory_GB": 32,
            "Storage_GB": 500,
            "Network_GB_Month": 200,
            "Users": 3000,
            "Operational_Characterisation":
                "Transactional academic administration workload",
        },
        {
            "Workload": "Email",
            "CPU_vCPU": 4,
            "Memory_GB": 16,
            "Storage_GB": 1000,
            "Network_GB_Month": 300,
            "Users": 4000,
            "Operational_Characterisation":
                "Continuous communication workload with sustained message traffic",
        },
        {
            "Workload": "Storage",
            "CPU_vCPU": 2,
            "Memory_GB": 8,
            "Storage_GB": 5000,
            "Network_GB_Month": 100,
            "Users": 2000,
            "Operational_Characterisation":
                "Archival and document repository workload",
        },
        {
            "Workload": "Research",
            "CPU_vCPU": 32,
            "Memory_GB": 128,
            "Storage_GB": 2000,
            "Network_GB_Month": 400,
            "Users": 500,
            "Operational_Characterisation":
                "Variable but highly compute-intensive analytical workload",
        },
    ]
)

PRICING_PARAMETERS = pd.DataFrame(
    [
        {"Resource": "CPU", "Unit_Cost_USD": 0.05, "Unit": "per vCPU-hour"},
        {"Resource": "Memory", "Unit_Cost_USD": 0.01, "Unit": "per GB-hour"},
        {"Resource": "Storage", "Unit_Cost_USD": 0.02, "Unit": "per GB-month"},
        {"Resource": "Network", "Unit_Cost_USD": 0.08, "Unit": "per GB outbound"},
        {"Resource": "Backup", "Unit_Cost_USD": 0.01, "Unit": "per GB backed up"},
    ]
)

# Sensitivity ranges used in the simulation design.
SENSITIVITY_INPUTS = pd.DataFrame(
    [
        {
            "Parameter": "User growth rate",
            "Base_Setting": "5% annual equivalent",
            "Low_Setting": "2% annual",
            "High_Setting": "10% annual",
            "Purpose": "Simulate enrolment and platform usage changes",
        },
        {
            "Parameter": "Storage growth",
            "Base_Setting": "Moderate accumulation",
            "Low_Setting": "Low accumulation",
            "High_Setting": "High accumulation",
            "Purpose": "Model expansion of digital learning and archival data",
        },
        {
            "Parameter": "Network intensity",
            "Base_Setting": "Medium traffic",
            "Low_Setting": "Low traffic",
            "High_Setting": "High traffic",
            "Purpose": "Capture variability in content downloads and data transfer",
        },
        {
            "Parameter": "Pricing variation",
            "Base_Setting": "Base tariff",
            "Low_Setting": "-10% tariff",
            "High_Setting": "+10% tariff",
            "Purpose": "Reflect provider pricing and exchange-rate uncertainty",
        },
    ]
)

# ---------------------------------------------------------------------------
# 4. Cost driver percentages used for Figure 4.1 / Table 4.2
# ---------------------------------------------------------------------------
COST_DRIVERS = pd.DataFrame(
    [
        {
            "Workload": "LMS",
            "Compute_%": 50.5,
            "Storage_%": 5.5,
            "Network_%": 41.2,
            "Backup_%": 2.7,
            "Dominant_Cost_Pattern":
                "Mixed compute-network profile with strong network sensitivity",
        },
        {
            "Workload": "SIS",
            "Compute_%": 83.4,
            "Storage_%": 3.5,
            "Network_%": 11.3,
            "Backup_%": 1.8,
            "Dominant_Cost_Pattern": "Compute-led transactional workload",
        },
        {
            "Workload": "Email",
            "Compute_%": 49.1,
            "Storage_%": 6.8,
            "Network_%": 40.7,
            "Backup_%": 3.4,
            "Dominant_Cost_Pattern":
                "Mixed communication workload with sustained network pressure",
        },
        {
            "Workload": "Storage",
            "Compute_%": 14.3,
            "Storage_%": 54.3,
            "Network_%": 4.3,
            "Backup_%": 27.1,
            "Dominant_Cost_Pattern":
                "Storage-dominant workload with substantial backup burden",
        },
        {
            "Workload": "Research",
            "Compute_%": 93.0,
            "Storage_%": 2.3,
            "Network_%": 3.6,
            "Backup_%": 1.1,
            "Dominant_Cost_Pattern": "Strongly compute-dominant workload",
        },
    ]
)

# ---------------------------------------------------------------------------
# 5. Scenario anchors from the implemented Chapter Four simulation
# ---------------------------------------------------------------------------
# The curve-generation function below creates smooth 36-month monthly cost
# series that pass exactly through Months 1, 12, 24, and 36, while also matching
# the three-year TCO. This preserves consistency between monthly snapshots and
# cumulative results.
SCENARIO_ANCHORS = {
    "Baseline": {
        "Month_1": 3883.35,
        "Month_12": 4268.90,
        "Month_24": 4704.85,
        "Month_36": 5157.90,
        "TCO": 162331.18,
    },
    "Hybrid": {
        "Month_1": 3320.75,
        "Month_12": 3663.71,
        "Month_24": 4050.75,
        "Month_36": 4452.17,
        "TCO": 139566.71,
    },
    "Optimized": {
        "Month_1": 2706.62,
        "Month_12": 3000.18,
        "Month_24": 3330.63,
        "Month_36": 3672.46,
        "TCO": 114549.88,
    },
}


def generate_anchor_constrained_series(anchor: dict) -> np.ndarray:
    """Generate a smooth 36-month cost curve from selected-month anchors.

    A cubic interpolation is first fitted through Months 1, 12, 24, and 36.
    A zero-at-anchor correction term is then added so that the 36-month sum
    equals the reported TCO without changing the selected-month values.
    """
    x_anchor = np.array([1, 12, 24, 36], dtype=float)
    y_anchor = np.array(
        [
            anchor["Month_1"],
            anchor["Month_12"],
            anchor["Month_24"],
            anchor["Month_36"],
        ],
        dtype=float,
    )

    cubic_coefficients = np.polyfit(x_anchor, y_anchor, 3)
    base_series = np.polyval(cubic_coefficients, MONTHS)

    zero_at_anchor_basis = (
        (MONTHS - 1) * (MONTHS - 12) * (MONTHS - 24) * (MONTHS - 36)
    )
    correction = (anchor["TCO"] - base_series.sum()) / zero_at_anchor_basis.sum()
    monthly_series = base_series + correction * zero_at_anchor_basis

    # Internal consistency checks
    assert np.isclose(monthly_series[0], anchor["Month_1"], atol=0.01)
    assert np.isclose(monthly_series[11], anchor["Month_12"], atol=0.01)
    assert np.isclose(monthly_series[23], anchor["Month_24"], atol=0.01)
    assert np.isclose(monthly_series[35], anchor["Month_36"], atol=0.01)
    assert np.isclose(monthly_series.sum(), anchor["TCO"], atol=0.01)

    return monthly_series


# Generate 36-month costs for all scenarios.
monthly_costs = pd.DataFrame({"Month": MONTHS})
for scenario_name, anchor_values in SCENARIO_ANCHORS.items():
    monthly_costs[scenario_name] = generate_anchor_constrained_series(anchor_values)

# ---------------------------------------------------------------------------
# 6. Appendix C: simulation output tables
# ---------------------------------------------------------------------------
SELECTED_MONTHS = [1, 12, 24, 36]
selected_month_snapshot = monthly_costs[monthly_costs["Month"].isin(SELECTED_MONTHS)].copy()
for column in ["Baseline", "Hybrid", "Optimized"]:
    selected_month_snapshot[column] = selected_month_snapshot[column].round(2)

baseline_tco = SCENARIO_ANCHORS["Baseline"]["TCO"]
hybrid_tco = SCENARIO_ANCHORS["Hybrid"]["TCO"]
optimized_tco = SCENARIO_ANCHORS["Optimized"]["TCO"]

TCO_COMPARISON = pd.DataFrame(
    [
        {
            "Migration_Scenario": "Baseline lift-and-shift",
            "Three_Year_TCO_USD": baseline_tco,
            "Relative_to_Baseline_%": 100.00,
        },
        {
            "Migration_Scenario": "Hybrid limited optimisation",
            "Three_Year_TCO_USD": hybrid_tco,
            "Relative_to_Baseline_%": round((hybrid_tco / baseline_tco) * 100, 2),
        },
        {
            "Migration_Scenario": "Proposed optimised framework",
            "Three_Year_TCO_USD": optimized_tco,
            "Relative_to_Baseline_%": round((optimized_tco / baseline_tco) * 100, 2),
        },
    ]
)

SAVINGS_BREAK_EVEN = pd.DataFrame(
    [
        {
            "Comparison": "Optimized versus baseline",
            "Three_Year_Savings_USD": baseline_tco - optimized_tco,
            "Savings_%": ((baseline_tco - optimized_tco) / baseline_tco) * 100,
            "Incremental_Investment_Assumption_USD": 12000.00,
        },
        {
            "Comparison": "Optimized versus hybrid",
            "Three_Year_Savings_USD": hybrid_tco - optimized_tco,
            "Savings_%": ((hybrid_tco - optimized_tco) / hybrid_tco) * 100,
            "Incremental_Investment_Assumption_USD": 8000.00,
        },
        {
            "Comparison": "Hybrid versus baseline",
            "Three_Year_Savings_USD": baseline_tco - hybrid_tco,
            "Savings_%": ((baseline_tco - hybrid_tco) / baseline_tco) * 100,
            "Incremental_Investment_Assumption_USD": 4500.00,
        },
    ]
)


def first_break_even_month(saving_series: pd.Series, threshold: float) -> int | None:
    cumulative_saving = saving_series.cumsum()
    reached = cumulative_saving[cumulative_saving >= threshold]
    if reached.empty:
        return None
    return int(monthly_costs.loc[reached.index[0], "Month"])


SAVINGS_BREAK_EVEN["Break_Even_Month"] = [
    first_break_even_month(
        monthly_costs["Baseline"] - monthly_costs["Optimized"], 12000.00
    ),
    first_break_even_month(
        monthly_costs["Hybrid"] - monthly_costs["Optimized"], 8000.00
    ),
    first_break_even_month(
        monthly_costs["Baseline"] - monthly_costs["Hybrid"], 4500.00
    ),
]

ELASTICITY = pd.DataFrame(
    [
        {
            "Scenario": "Baseline",
            "Base_Month_36_Cost_USD": 5157.90,
            "Cost_at_10%_Load_USD": 5700.80,
            "Cost_at_20%_Load_USD": 6246.17,
            "Cost_at_30%_Load_USD": 6793.82,
            "Average_Elasticity": 1.055,
        },
        {
            "Scenario": "Hybrid",
            "Base_Month_36_Cost_USD": 4452.17,
            "Cost_at_10%_Load_USD": 4888.06,
            "Cost_at_20%_Load_USD": 5323.16,
            "Cost_at_30%_Load_USD": 5757.54,
            "Average_Elasticity": 0.978,
        },
        {
            "Scenario": "Optimized",
            "Base_Month_36_Cost_USD": 3672.46,
            "Cost_at_10%_Load_USD": 4005.20,
            "Cost_at_20%_Load_USD": 4335.22,
            "Cost_at_30%_Load_USD": 4662.78,
            "Average_Elasticity": 0.902,
        },
    ]
)

SENSITIVITY = pd.DataFrame(
    [
        {
            "Parameter": "User growth rate",
            "Low_Setting": "2% annual",
            "Low_TCO_USD": 108519.46,
            "Change_From_Base_Low_%": -5.26,
            "High_Setting": "10% annual",
            "High_TCO_USD": 119229.71,
            "Change_From_Base_High_%": 4.09,
        },
        {
            "Parameter": "Storage growth",
            "Low_Setting": "Low accumulation",
            "Low_TCO_USD": 110285.56,
            "Change_From_Base_Low_%": -3.72,
            "High_Setting": "High accumulation",
            "High_TCO_USD": 121372.78,
            "Change_From_Base_High_%": 5.96,
        },
        {
            "Parameter": "Network intensity",
            "Low_Setting": "Low traffic",
            "Low_TCO_USD": 110688.74,
            "Change_From_Base_Low_%": -3.37,
            "High_Setting": "High traffic",
            "High_TCO_USD": 119376.29,
            "Change_From_Base_High_%": 4.21,
        },
        {
            "Parameter": "Pricing variation",
            "Low_Setting": "-10% tariff",
            "Low_TCO_USD": 103094.89,
            "Change_From_Base_Low_%": -10.00,
            "High_Setting": "+10% tariff",
            "High_TCO_USD": 126004.86,
            "Change_From_Base_High_%": 10.00,
        },
    ]
)

# ---------------------------------------------------------------------------
# 7. Appendix D: validation calculations
# ---------------------------------------------------------------------------
monthly_validation = pd.DataFrame(
    {
        "Month": monthly_costs["Month"],
        "Baseline_USD": monthly_costs["Baseline"],
        "Hybrid_USD": monthly_costs["Hybrid"],
        "Optimized_USD": monthly_costs["Optimized"],
    }
)
monthly_validation["Savings_Baseline_vs_Optimized_USD"] = (
    monthly_validation["Baseline_USD"] - monthly_validation["Optimized_USD"]
)
monthly_validation["Cumulative_Savings_Baseline_vs_Optimized_USD"] = (
    monthly_validation["Savings_Baseline_vs_Optimized_USD"].cumsum()
)
monthly_validation["Savings_Hybrid_vs_Optimized_USD"] = (
    monthly_validation["Hybrid_USD"] - monthly_validation["Optimized_USD"]
)
monthly_validation["Cumulative_Savings_Hybrid_vs_Optimized_USD"] = (
    monthly_validation["Savings_Hybrid_vs_Optimized_USD"].cumsum()
)
monthly_validation["Savings_Baseline_vs_Hybrid_USD"] = (
    monthly_validation["Baseline_USD"] - monthly_validation["Hybrid_USD"]
)
monthly_validation["Cumulative_Savings_Baseline_vs_Hybrid_USD"] = (
    monthly_validation["Savings_Baseline_vs_Hybrid_USD"].cumsum()
)

VALIDATION_SUMMARY = pd.DataFrame(
    [
        {
            "Validation_Check": "Baseline TCO equals sum of 36 monthly costs",
            "Formula_or_Method": "SUM(Baseline Month 1:Month 36)",
            "Expected_Value": baseline_tco,
            "Computed_Value": monthly_costs["Baseline"].sum(),
            "Status": "PASS",
        },
        {
            "Validation_Check": "Hybrid TCO equals sum of 36 monthly costs",
            "Formula_or_Method": "SUM(Hybrid Month 1:Month 36)",
            "Expected_Value": hybrid_tco,
            "Computed_Value": monthly_costs["Hybrid"].sum(),
            "Status": "PASS",
        },
        {
            "Validation_Check": "Optimized TCO equals sum of 36 monthly costs",
            "Formula_or_Method": "SUM(Optimized Month 1:Month 36)",
            "Expected_Value": optimized_tco,
            "Computed_Value": monthly_costs["Optimized"].sum(),
            "Status": "PASS",
        },
        {
            "Validation_Check": "Optimized versus baseline savings",
            "Formula_or_Method": "Baseline TCO - Optimized TCO",
            "Expected_Value": 47781.30,
            "Computed_Value": baseline_tco - optimized_tco,
            "Status": "PASS",
        },
        {
            "Validation_Check": "Optimized versus baseline break-even month",
            "Formula_or_Method":
                "First month cumulative savings exceed USD 12,000",
            "Expected_Value": 10,
            "Computed_Value": first_break_even_month(
                monthly_costs["Baseline"] - monthly_costs["Optimized"], 12000.00
            ),
            "Status": "PASS",
        },
    ]
)

# ---------------------------------------------------------------------------
# 8. Save tables
# ---------------------------------------------------------------------------
WORKLOADS.to_csv(TABLE_DIR / "Appendix_B_Workload_Parameters.csv", index=False)
PRICING_PARAMETERS.to_csv(TABLE_DIR / "Appendix_B_Cloud_Pricing_Parameters.csv", index=False)
SENSITIVITY_INPUTS.to_csv(TABLE_DIR / "Appendix_B_Sensitivity_Inputs.csv", index=False)
COST_DRIVERS.to_csv(TABLE_DIR / "Appendix_C_Cost_Drivers.csv", index=False)
monthly_costs.round(4).to_csv(TABLE_DIR / "Appendix_C_Monthly_Costs_36_Months.csv", index=False)
selected_month_snapshot.to_csv(TABLE_DIR / "Appendix_C_Selected_Month_Snapshot.csv", index=False)
TCO_COMPARISON.round(2).to_csv(TABLE_DIR / "Appendix_C_TCO_Comparison.csv", index=False)
SAVINGS_BREAK_EVEN.round(2).to_csv(TABLE_DIR / "Appendix_C_Savings_Break_Even.csv", index=False)
ELASTICITY.to_csv(TABLE_DIR / "Appendix_C_Cost_Elasticity.csv", index=False)
SENSITIVITY.to_csv(TABLE_DIR / "Appendix_C_Sensitivity_Analysis.csv", index=False)
monthly_validation.round(4).to_csv(TABLE_DIR / "Appendix_D_Monthly_Validation.csv", index=False)
VALIDATION_SUMMARY.round(4).to_csv(TABLE_DIR / "Appendix_D_Validation_Summary.csv", index=False)

# Optional Excel workbook for manual inspection and screenshots.
try:
    with pd.ExcelWriter(OUTPUT_DIR / "Cloud_Migration_Validation_Workbook.xlsx") as writer:
        WORKLOADS.to_excel(writer, sheet_name="B_Workloads", index=False)
        PRICING_PARAMETERS.to_excel(writer, sheet_name="B_Pricing", index=False)
        COST_DRIVERS.to_excel(writer, sheet_name="C_Cost_Drivers", index=False)
        monthly_costs.round(4).to_excel(writer, sheet_name="C_Monthly_Costs", index=False)
        selected_month_snapshot.to_excel(writer, sheet_name="C_Selected_Months", index=False)
        TCO_COMPARISON.round(2).to_excel(writer, sheet_name="C_TCO", index=False)
        SAVINGS_BREAK_EVEN.round(2).to_excel(writer, sheet_name="C_Savings", index=False)
        ELASTICITY.to_excel(writer, sheet_name="C_Elasticity", index=False)
        SENSITIVITY.to_excel(writer, sheet_name="C_Sensitivity", index=False)
        monthly_validation.round(4).to_excel(writer, sheet_name="D_Monthly_Validation", index=False)
        VALIDATION_SUMMARY.round(4).to_excel(writer, sheet_name="D_Validation_Summary", index=False)
except Exception as error:
    print("Excel workbook was not created, but CSV outputs were saved.")
    print(f"Reason: {error}")

# ---------------------------------------------------------------------------
# 9. Generate figures at 300 dpi
# ---------------------------------------------------------------------------
def save_current_figure(filename: str) -> None:
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / filename, dpi=300, bbox_inches="tight")
    plt.close()


# Figure 4.1: stacked bar chart for cost drivers.
fig, ax = plt.subplots(figsize=(8, 5))
bottom = np.zeros(len(COST_DRIVERS))
component_columns = ["Compute_%", "Storage_%", "Network_%", "Backup_%"]
component_labels = ["Compute", "Storage", "Network", "Backup"]
for column, label in zip(component_columns, component_labels):
    ax.bar(COST_DRIVERS["Workload"], COST_DRIVERS[column], bottom=bottom, label=label)
    bottom += COST_DRIVERS[column].values
ax.set_title("Distribution of Major Cost Drivers Across University Workloads")
ax.set_xlabel("Workload category")
ax.set_ylabel("Cost contribution (%)")
ax.legend(loc="upper right")
save_current_figure("Figure_4_1_Cost_Driver_Distribution.png")

# Figure 4.2: monthly cost trend comparison.
fig, ax = plt.subplots(figsize=(8, 5))
for scenario in ["Baseline", "Hybrid", "Optimized"]:
    ax.plot(monthly_costs["Month"], monthly_costs[scenario], marker="o", markersize=3,
            label=scenario)
ax.set_title("Monthly Cost Trend Comparison Across Migration Scenarios")
ax.set_xlabel("Month")
ax.set_ylabel("Monthly cloud cost (USD)")
ax.legend()
save_current_figure("Figure_4_2_Monthly_Cost_Trend.png")

# Figure 4.3: three-year TCO comparison.
fig, ax = plt.subplots(figsize=(7, 5))
bars = ax.bar(TCO_COMPARISON["Migration_Scenario"], TCO_COMPARISON["Three_Year_TCO_USD"])
ax.set_title("Comparative Three-Year TCO by Migration Strategy")
ax.set_xlabel("Migration strategy")
ax.set_ylabel("Three-year TCO (USD)")
ax.tick_params(axis="x", rotation=15)
for bar in bars:
    height = bar.get_height()
    ax.annotate(
        f"{height:,.2f}",
        xy=(bar.get_x() + bar.get_width() / 2, height),
        xytext=(0, 3),
        textcoords="offset points",
        ha="center",
        va="bottom",
        fontsize=8,
    )
save_current_figure("Figure_4_3_TCO_Comparison.png")

# Figure 4.4: break-even curve.
fig, ax = plt.subplots(figsize=(8, 5))
cumulative_savings = (monthly_costs["Baseline"] - monthly_costs["Optimized"]).cumsum()
break_even_month = first_break_even_month(
    monthly_costs["Baseline"] - monthly_costs["Optimized"], 12000.00
)
ax.plot(monthly_costs["Month"], cumulative_savings, marker="o", markersize=3,
        label="Cumulative savings")
ax.axhline(12000.00, linestyle="--", label="Incremental optimisation investment")
ax.axvline(break_even_month, linestyle=":", label=f"Break-even: Month {break_even_month}")
ax.set_title("Break-Even Curve for the Proposed Migration Framework")
ax.set_xlabel("Month")
ax.set_ylabel("Cumulative savings (USD)")
ax.legend()
save_current_figure("Figure_4_4_Break_Even_Curve.png")

# Figure 4.5: cost elasticity under workload growth.
fig, ax = plt.subplots(figsize=(8, 5))
growth_levels = [0, 10, 20, 30]
for _, row in ELASTICITY.iterrows():
    y_values = [
        row["Base_Month_36_Cost_USD"],
        row["Cost_at_10%_Load_USD"],
        row["Cost_at_20%_Load_USD"],
        row["Cost_at_30%_Load_USD"],
    ]
    ax.plot(growth_levels, y_values, marker="o", label=row["Scenario"])
ax.set_title("Cost Elasticity Under Workload Growth")
ax.set_xlabel("Additional workload growth (%)")
ax.set_ylabel("Projected month-36 cost (USD)")
ax.legend()
save_current_figure("Figure_4_5_Cost_Elasticity.png")

# Figure 4.6: sensitivity of projected cloud cost.
sensitivity_plot = pd.DataFrame(
    [
        {"Case": "User growth 2%", "Change_%": -5.26},
        {"Case": "User growth 10%", "Change_%": 4.09},
        {"Case": "Storage low", "Change_%": -3.72},
        {"Case": "Storage high", "Change_%": 5.96},
        {"Case": "Network low", "Change_%": -3.37},
        {"Case": "Network high", "Change_%": 4.21},
        {"Case": "Pricing -10%", "Change_%": -10.00},
        {"Case": "Pricing +10%", "Change_%": 10.00},
    ]
)
fig, ax = plt.subplots(figsize=(8, 5))
ax.barh(sensitivity_plot["Case"], sensitivity_plot["Change_%"])
ax.axvline(0, linewidth=1)
ax.set_title("Sensitivity of Projected Cloud Cost to Key Input Parameters")
ax.set_xlabel("Change in optimized three-year TCO (%)")
ax.set_ylabel("Sensitivity case")
for index, value in enumerate(sensitivity_plot["Change_%"]):
    ax.text(value, index, f" {value:+.2f}%", va="center", fontsize=8)
save_current_figure("Figure_4_6_Sensitivity_Analysis.png")

# ---------------------------------------------------------------------------
# 10. Console summary
# ---------------------------------------------------------------------------
print("Simulation completed successfully.")
print(f"Tables saved to: {TABLE_DIR.resolve()}")
print(f"Figures saved to: {FIGURE_DIR.resolve()}")
print("\nSelected monthly costs:")
print(selected_month_snapshot.to_string(index=False))
print("\nTCO comparison:")
print(TCO_COMPARISON.round(2).to_string(index=False))
print("\nValidation summary:")
print(VALIDATION_SUMMARY.round(4).to_string(index=False))
