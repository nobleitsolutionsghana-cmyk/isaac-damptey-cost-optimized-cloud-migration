from __future__ import annotations


def percent_change(base_value: float, changed_value: float) -> float:
    if base_value == 0:
        raise ValueError("Base value cannot be zero.")
    return (changed_value - base_value) / base_value * 100.0


def uniform_pricing_sensitivity(base_tco: float, price_change_fraction: float) -> float:
    """Reproduce the thesis ±10% uniform pricing sensitivity arithmetic."""
    if price_change_fraction <= -1:
        raise ValueError("Price reduction cannot be 100% or more.")
    return base_tco * (1.0 + price_change_fraction)
