from __future__ import annotations
import math


def annual_to_monthly_rate(annual_rate: float) -> float:
    """Convert an annual compound growth rate to its equivalent monthly rate."""
    if annual_rate <= -1:
        raise ValueError("Annual growth must be greater than -100%.")
    return (1.0 + annual_rate) ** (1.0 / 12.0) - 1.0


def workload_vector(cpu: float, memory: float, storage: float, network: float,
                    users: float, intensity: float, workload_class: str) -> tuple:
    """Implements Equation (3.1)."""
    return (cpu, memory, storage, network, users, intensity, workload_class)


def user_growth(users_0: float, monthly_growth: float, month: int) -> float:
    """Implements Equation (3.2)."""
    if users_0 < 0 or month < 0:
        raise ValueError("Users and month must be non-negative.")
    return users_0 * (1.0 + monthly_growth) ** month


def storage_growth(storage_0: float, monthly_accumulation: float, month: int) -> float:
    """Implements Equation (3.3)."""
    if storage_0 < 0 or month < 0:
        raise ValueError("Storage and month must be non-negative.")
    result = storage_0 + monthly_accumulation * month
    if result < 0:
        raise ValueError("Storage cannot become negative.")
    return result


def compute_demand(cpu_0: float, users_t: float, users_0: float, intensity: float) -> float:
    """Implements Equation (3.4)."""
    if users_0 <= 0:
        raise ValueError("Baseline users must be positive.")
    return cpu_0 * (1.0 + intensity * (users_t / users_0 - 1.0))


def memory_demand(mem_0: float, users_t: float, users_0: float, intensity: float) -> float:
    """Implements Equation (3.5)."""
    if users_0 <= 0:
        raise ValueError("Baseline users must be positive.")
    return mem_0 * (1.0 + intensity * (users_t / users_0 - 1.0))


def network_demand(network_0: float, users_t: float, users_0: float, traffic_sensitivity: float) -> float:
    """Implements Equation (3.6)."""
    if users_0 <= 0:
        raise ValueError("Baseline users must be positive.")
    return network_0 * (1.0 + traffic_sensitivity * (users_t / users_0 - 1.0))
