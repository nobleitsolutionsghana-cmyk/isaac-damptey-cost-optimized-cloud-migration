class ParameterResolutionError(ValueError):
    """Raised when a thesis-required parameter is absent and must not be invented."""

    def __init__(self, missing: list[str], context: str = "first-principles simulation"):
        self.missing = missing
        self.context = context
        super().__init__(f"Unresolved parameters for {context}: {', '.join(missing)}")
