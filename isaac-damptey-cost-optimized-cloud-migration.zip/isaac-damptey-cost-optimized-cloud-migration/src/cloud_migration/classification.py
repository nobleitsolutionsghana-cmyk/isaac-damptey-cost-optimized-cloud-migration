from __future__ import annotations
from typing import Mapping
import pandas as pd
from .exceptions import ParameterResolutionError


def normalised_resource_scores(workloads: pd.DataFrame) -> pd.DataFrame:
    """Implements Equation (3.15) for CPU, storage and network scores."""
    out = workloads[["workload_id", "cpu_vcpu", "storage_gb", "network_gb_month"]].copy()
    for col in ["cpu_vcpu", "storage_gb", "network_gb_month"]:
        maximum = float(out[col].max())
        if maximum <= 0:
            raise ValueError(f"Cannot normalise {col} with non-positive maximum.")
    out["x_cpu"] = out["cpu_vcpu"] / out["cpu_vcpu"].max()
    out["x_sto"] = out["storage_gb"] / out["storage_gb"].max()
    out["x_net"] = out["network_gb_month"] / out["network_gb_month"].max()
    return out[["workload_id", "x_cpu", "x_sto", "x_net"]]


def classify_scores(x_cpu: float, x_sto: float, x_net: float,
                    thresholds: Mapping[str, float] | None) -> str:
    """Apply thesis-described threshold comparison without inventing thresholds."""
    if thresholds is None:
        raise ParameterResolutionError(["classification thresholds"], "workload classification")
    required = {"compute", "storage", "network"}
    missing = sorted(required.difference(thresholds))
    if missing:
        raise ParameterResolutionError([f"classification threshold: {x}" for x in missing], "workload classification")
    hits = []
    if x_cpu >= thresholds["compute"]:
        hits.append("compute-intensive")
    if x_sto >= thresholds["storage"]:
        hits.append("storage-intensive")
    if x_net >= thresholds["network"]:
        hits.append("network-sensitive")
    if len(hits) == 1:
        return hits[0]
    return "mixed/transactional"
