from __future__ import annotations
import math


def utilisation(cpu_demand: float, previous_cpu_alloc: float) -> float:
    """Implements Equation (3.20)."""
    if previous_cpu_alloc <= 0:
        raise ValueError("Previous CPU allocation must be positive.")
    return cpu_demand / previous_cpu_alloc


def scaling_factor(utilisation_ratio: float, u_low: float, u_up: float,
                   mu: float, zeta: float) -> float:
    """Implements Equation (3.21)."""
    if not (0 <= u_low <= u_up):
        raise ValueError("Require 0 <= u_low <= u_up.")
    if mu < 0 or zeta < 0 or mu >= 1:
        raise ValueError("Scaling adjustments are invalid.")
    if utilisation_ratio > u_up:
        return 1.0 + zeta
    if utilisation_ratio < u_low:
        return 1.0 - mu
    return 1.0


def autoscale_cpu(cpu_demand: float, phi: float, cpu_min: float, cpu_max: float) -> int:
    """Implements Equation (3.22)."""
    if cpu_min < 0 or cpu_max < cpu_min or cpu_demand < 0 or phi <= 0:
        raise ValueError("Invalid auto-scaling bounds or inputs.")
    return int(min(cpu_max, max(cpu_min, math.ceil(phi * cpu_demand))))
