from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd


def load_scenario_anchors(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path)


def generate_anchor_constrained_series(month_1: float, month_12: float, month_24: float,
                                       month_36: float, tco_target: float,
                                       simulation_months: int = 36) -> np.ndarray:
    """Implements Equations (3.24)–(3.26).

    This is the thesis's deterministic reporting reconstruction, not the
    first-principles migration optimisation model.
    """
    if simulation_months != 36:
        raise ValueError("The documented anchor procedure is defined for the 36-month thesis horizon.")
    months = np.arange(1, simulation_months + 1, dtype=float)
    x_anchor = np.array([1, 12, 24, 36], dtype=float)
    y_anchor = np.array([month_1, month_12, month_24, month_36], dtype=float)
    cubic_coefficients = np.polyfit(x_anchor, y_anchor, 3)
    q = np.polyval(cubic_coefficients, months)
    z = (months - 1) * (months - 12) * (months - 24) * (months - 36)
    denominator = float(z.sum())
    if abs(denominator) < 1e-12:
        raise ZeroDivisionError("Anchor correction basis has zero sum.")
    kappa = (tco_target - float(q.sum())) / denominator
    series = q + kappa * z
    assert np.isclose(series[0], month_1, atol=0.01)
    assert np.isclose(series[11], month_12, atol=0.01)
    assert np.isclose(series[23], month_24, atol=0.01)
    assert np.isclose(series[35], month_36, atol=0.01)
    assert np.isclose(series.sum(), tco_target, atol=0.01)
    return series


def reconstruct_all(anchor_df: pd.DataFrame) -> pd.DataFrame:
    months = np.arange(1, 37)
    out = pd.DataFrame({"Month": months})
    for _, row in anchor_df.iterrows():
        out[row["scenario"]] = generate_anchor_constrained_series(
            float(row["month_1"]), float(row["month_12"]), float(row["month_24"]),
            float(row["month_36"]), float(row["tco_usd"])
        )
    return out
