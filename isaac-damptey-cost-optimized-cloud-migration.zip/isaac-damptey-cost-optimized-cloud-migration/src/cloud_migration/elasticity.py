from __future__ import annotations
import numpy as np


def point_elasticity(base_cost: float, changed_cost: float, load_change_fraction: float) -> float:
    """Implements Equation (3.29) for L1/L0 = 1 + load_change_fraction."""
    if base_cost <= 0 or load_change_fraction == 0:
        raise ValueError("Base cost must be positive and workload change non-zero.")
    return ((changed_cost - base_cost) / base_cost) / load_change_fraction


def average_elasticity(base_cost: float, changed_costs: list[float], load_change_fractions: list[float]) -> float:
    if len(changed_costs) != len(load_change_fractions):
        raise ValueError("Changed costs and workload changes must align.")
    vals = [point_elasticity(base_cost, c, g) for c, g in zip(changed_costs, load_change_fractions)]
    return float(np.mean(vals))
