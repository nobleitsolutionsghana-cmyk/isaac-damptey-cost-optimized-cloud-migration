from __future__ import annotations
import numpy as np


def tco(monthly_costs) -> float:
    """Implements Equation (3.12)."""
    arr = np.asarray(monthly_costs, dtype=float)
    if np.any(arr < 0):
        raise ValueError("Monthly costs cannot be negative.")
    return float(arr.sum())


def savings_amount(lower_tco: float, comparator_tco: float) -> float:
    return comparator_tco - lower_tco


def savings_percent(lower_tco: float, comparator_tco: float) -> float:
    """Implements Equation (3.27)."""
    if comparator_tco <= 0:
        raise ValueError("Comparator TCO must be positive.")
    return (comparator_tco - lower_tco) / comparator_tco * 100.0
