from __future__ import annotations
import numpy as np


def break_even_month(comparator_costs, lower_costs, investment: float) -> int | None:
    """Implements Equation (3.28)."""
    if investment < 0:
        raise ValueError("Investment must be non-negative.")
    comparator = np.asarray(comparator_costs, dtype=float)
    lower = np.asarray(lower_costs, dtype=float)
    if comparator.shape != lower.shape:
        raise ValueError("Cost series must have identical shape.")
    cumulative = np.cumsum(comparator - lower)
    hits = np.flatnonzero(cumulative >= investment)
    return None if len(hits) == 0 else int(hits[0] + 1)
