from __future__ import annotations
from collections.abc import Mapping
from .exceptions import ParameterResolutionError


def composite_score(cost_norm: float, performance_penalty_norm: float,
                    governance_burden_norm: float, alpha: float, beta: float, gamma: float) -> float:
    """Implements Equation (3.16)."""
    if abs(alpha + beta + gamma - 1.0) > 1e-9:
        raise ValueError("alpha + beta + gamma must equal 1.")
    if any(x < 0 for x in [alpha, beta, gamma]):
        raise ValueError("Weights must be non-negative.")
    return alpha * cost_norm + beta * performance_penalty_norm + gamma * governance_burden_norm


def select_minimum_score(scores: Mapping[str, float]) -> str:
    """Implements Equation (3.17)."""
    if not scores:
        raise ValueError("At least one feasible strategy is required.")
    return min(scores, key=scores.get)


def require_strategy_weights(weights: Mapping[str, float] | None) -> Mapping[str, float]:
    if weights is None:
        raise ParameterResolutionError(["alpha", "beta", "gamma"], "migration strategy selection")
    return weights
