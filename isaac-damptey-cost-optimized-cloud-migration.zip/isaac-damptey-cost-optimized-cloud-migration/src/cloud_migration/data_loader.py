from __future__ import annotations
from pathlib import Path
import pandas as pd


def load_csv(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path)


def load_workloads(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"workload_id", "cpu_vcpu", "memory_gb", "storage_gb", "network_gb_month", "users"}
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError(f"Workload file is missing columns: {missing}")
    if (df[["cpu_vcpu", "memory_gb", "storage_gb", "network_gb_month", "users"]].astype(float) < 0).any().any():
        raise ValueError("Workload resource values must be non-negative.")
    return df


def load_pricing(path: str | Path) -> dict[str, float]:
    df = pd.read_csv(path)
    mapping = {str(r["resource"]).lower(): float(r["unit_cost_usd"]) for _, r in df.iterrows()}
    expected = {"cpu", "memory", "storage", "network", "backup"}
    missing = sorted(expected.difference(mapping))
    if missing:
        raise ValueError(f"Pricing file is missing resources: {missing}")
    if any(v < 0 for v in mapping.values()):
        raise ValueError("Pricing values must be non-negative.")
    return mapping
