from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
from .reporting_reproduction import reconstruct_all
from .metrics import tco, savings_amount, savings_percent
from .break_even import break_even_month
from .elasticity import average_elasticity
from .sensitivity import percent_change, uniform_pricing_sensitivity


def build_validation_rows(reference_dir: str | Path) -> pd.DataFrame:
    ref = Path(reference_dir)
    anchors = pd.read_csv(ref / "scenario_anchors.csv")
    monthly = reconstruct_all(anchors)
    targets = {r["scenario"]: float(r["tco_usd"]) for _, r in anchors.iterrows()}
    rows = []
    for scenario in ["Baseline", "Hybrid", "Optimized"]:
        reproduced = tco(monthly[scenario])
        rows.append([f"TCO {scenario}", targets[scenario], reproduced, reproduced-targets[scenario], 0.01,
                     "PASS" if abs(reproduced-targets[scenario]) <= 0.01 else "FAIL",
                     "Exact thesis-faithful reconstruction"])
        for month, col in [(1,"month_1"),(12,"month_12"),(24,"month_24"),(36,"month_36")]:
            thesis = float(anchors.loc[anchors.scenario==scenario, col].iloc[0])
            rep = float(monthly.loc[monthly.Month==month, scenario].iloc[0])
            rows.append([f"{scenario} Month {month}", thesis, rep, rep-thesis, 0.01,
                         "PASS" if abs(rep-thesis) <= 0.01 else "FAIL",
                         "Exact thesis-faithful reconstruction"])
    b,h,o = targets["Baseline"],targets["Hybrid"],targets["Optimized"]
    comparisons=[
        ("Optimized vs Baseline",o,b,12000,10),
        ("Optimized vs Hybrid",o,h,8000,13),
        ("Hybrid vs Baseline",h,b,4500,8),
    ]
    series={s: monthly[s].to_numpy() for s in ["Baseline","Hybrid","Optimized"]}
    for label, low, comp, investment, be_target in comparisons:
        amount=savings_amount(low,comp); pct=savings_percent(low,comp)
        rows.append([f"Savings amount {label}", comp-low, amount, 0.0, 0.01,"PASS","Derived from reconstructed TCO"])
        thesis_pct={"Optimized vs Baseline":29.43,"Optimized vs Hybrid":17.92,"Hybrid vs Baseline":14.02}[label]
        rows.append([f"Savings percent {label}", thesis_pct, pct, pct-thesis_pct,0.01,
                     "PASS" if abs(pct-thesis_pct)<=0.01 else "FAIL","Derived from reconstructed TCO"])
        if label=="Optimized vs Baseline": be=break_even_month(series["Baseline"],series["Optimized"],investment)
        elif label=="Optimized vs Hybrid": be=break_even_month(series["Hybrid"],series["Optimized"],investment)
        else: be=break_even_month(series["Baseline"],series["Hybrid"],investment)
        rows.append([f"Break-even {label}",be_target,be,be-be_target,0,"PASS" if be==be_target else "FAIL","Derived from reconstructed monthly series"])

    elastic = pd.read_csv(ref / "elasticity_reported.csv")
    for scenario, group in elastic.groupby("scenario", sort=False):
        group=group.sort_values("load_change_pct")
        base=float(group.loc[group.load_change_pct==0,"cost_usd"].iloc[0])
        changed=[float(group.loc[group.load_change_pct==x,"cost_usd"].iloc[0]) for x in [10,20,30]]
        calc=average_elasticity(base,changed,[0.1,0.2,0.3])
        target=float(group["reported_average_elasticity"].iloc[0])
        rows.append([f"Average elasticity {scenario}",target,calc,calc-target,0.002,
                     "PASS" if abs(calc-target)<=0.002 else "FAIL","Average derived from reported load-cost points; load-cost points are reference-only"])

    sens=pd.read_csv(ref / "sensitivity_reported.csv")
    base=o
    for _,r in sens.iterrows():
        calc=percent_change(base,float(r["tco_usd"]))
        target=float(r["reported_change_pct"])
        rows.append([f"Sensitivity change {r['parameter']} {r['setting']}",target,calc,calc-target,0.01,
                     "PASS" if abs(calc-target)<=0.01 else "FAIL","Change percentage derived from reported alternate TCO"])
    for frac,target in [(-0.10,103094.89),(0.10,126004.86)]:
        calc=uniform_pricing_sensitivity(o,frac)
        rows.append([f"Uniform pricing sensitivity {frac:+.0%}",target,calc,calc-target,0.01,
                     "PASS" if abs(calc-target)<=0.01 else "FAIL","Independently derived under uniform tariff scaling"])
    return pd.DataFrame(rows,columns=["metric","thesis_value","reproduced_value","difference","tolerance","status","reproduction_basis"])
