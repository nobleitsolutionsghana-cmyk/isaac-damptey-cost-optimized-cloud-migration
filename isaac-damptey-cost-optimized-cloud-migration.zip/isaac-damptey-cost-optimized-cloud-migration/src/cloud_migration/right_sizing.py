from __future__ import annotations
import math


def right_size(cpu_demand: float, mem_demand: float, rho_cpu: float, rho_mem: float) -> tuple[int, int]:
    """Implements Equations (3.18) and (3.19)."""
    if any(v < 0 for v in [cpu_demand, mem_demand, rho_cpu, rho_mem]):
        raise ValueError("Right-sizing inputs must be non-negative.")
    cpu_alloc = math.ceil((1.0 + rho_cpu) * cpu_demand)
    mem_alloc = math.ceil((1.0 + rho_mem) * mem_demand)
    if cpu_alloc < cpu_demand or mem_alloc < mem_demand:
        raise AssertionError("Right-sizing must not under-provision modelled demand.")
    return cpu_alloc, mem_alloc
