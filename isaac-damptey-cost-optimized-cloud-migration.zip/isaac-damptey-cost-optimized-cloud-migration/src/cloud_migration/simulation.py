from __future__ import annotations
from pathlib import Path
import math
import pandas as pd
from .config import load_yaml
from .data_loader import load_workloads, load_pricing
from .exceptions import ParameterResolutionError
from .workload_model import annual_to_monthly_rate, user_growth, storage_growth, compute_demand, memory_demand, network_demand
from .right_sizing import right_size
from .autoscaling import utilisation, scaling_factor, autoscale_cpu
from .reserved_capacity import effective_compute_cost
from .cost_model import compute_memory_cost, storage_cost, network_cost, backup_cost, aggregate_cost
from .scenarios import validate_scenario_parameters


def _required_workload_parameters(df: pd.DataFrame) -> list[str]:
    missing = []
    for col in ["intensity_coefficient", "traffic_sensitivity", "backup_fraction", "storage_growth_gb_month"]:
        if col not in df.columns or df[col].isna().any():
            missing.append(col)
    return missing


def parameter_completeness_report(workloads: pd.DataFrame, scenario_name: str, scenario_cfg: dict) -> list[str]:
    missing = _required_workload_parameters(workloads)
    try:
        validate_scenario_parameters(scenario_name, scenario_cfg)
    except ParameterResolutionError as exc:
        missing.extend(exc.missing)
    return sorted(set(missing))


def run_first_principles(workloads_path: str | Path, pricing_path: str | Path,
                         base_config_path: str | Path, scenario_path: str | Path) -> pd.DataFrame:
    """Demonstrate model equations under explicit, externally supplied settings.

    WARNING: This is a partial first-principles pipeline, not an authenticated
    implementation of all Chapter Three institutional governance and assignment
    choices. Exact historical reproduction is blocked by missing parameters and
    incompletely specified baseline/hybrid/optimised treatment rules. Scenario
    assignment policy must be audited before any newly configured runs can be
    described as matching the historical thesis experiment.
    """
    workloads = load_workloads(workloads_path)
    pricing = load_pricing(pricing_path)
    base_cfg = load_yaml(base_config_path)
    scenario = load_yaml(scenario_path)
    scenario_name = scenario["scenario"]
    missing = parameter_completeness_report(workloads, scenario_name, scenario)
    if missing:
        raise ParameterResolutionError(missing, f"first-principles {scenario_name} simulation")

    months = int(base_cfg["model"]["simulation_months"])
    hours = float(base_cfg["model"]["hours_per_month"])
    annual_growth = float(base_cfg["model"]["base_annual_user_growth"])
    monthly_g = annual_to_monthly_rate(annual_growth)
    records = []
    previous_cpu = {}

    for _, w in workloads.iterrows():
        previous_cpu[w["workload_id"]] = float(w["cpu_vcpu"])

    for month in range(1, months + 1):
        for _, w in workloads.iterrows():
            users_t = user_growth(float(w["users"]), monthly_g, month)
            sto_t = storage_growth(float(w["storage_gb"]), float(w["storage_growth_gb_month"]), month)
            cpu_dem = compute_demand(float(w["cpu_vcpu"]), users_t, float(w["users"]), float(w["intensity_coefficient"]))
            mem_dem = memory_demand(float(w["memory_gb"]), users_t, float(w["users"]), float(w["intensity_coefficient"]))
            net_t = network_demand(float(w["network_gb_month"]), users_t, float(w["users"]), float(w["traffic_sensitivity"]))
            backup_gb = sto_t * float(w["backup_fraction"])

            if scenario_name == "baseline":
                factor = float(scenario["overprovisioning_factor"])
                cpu_alloc = math.ceil(cpu_dem * factor)
                mem_alloc = math.ceil(mem_dem * factor)
            else:
                cpu_alloc, mem_alloc = right_size(cpu_dem, mem_dem, float(scenario["rho_cpu"]), float(scenario["rho_mem"]))
                if scenario_name == "optimized":
                    util = utilisation(cpu_dem, previous_cpu[w["workload_id"]])
                    phi = scaling_factor(util, float(scenario["u_low"]), float(scenario["u_up"]),
                                         float(scenario["mu"]), float(scenario["zeta"]))
                    cpu_alloc = autoscale_cpu(cpu_dem, phi, float(scenario["cpu_min"]), float(scenario["cpu_max"]))

            comp = compute_memory_cost(cpu_alloc, mem_alloc, pricing["cpu"], pricing["memory"], hours)
            if scenario_name in {"hybrid", "optimized"}:
                comp = effective_compute_cost(comp, float(scenario["reserved_fraction"]), float(scenario["reserved_discount"]))
            sto_c = storage_cost(sto_t, pricing["storage"])
            net_c = network_cost(net_t, pricing["network"])
            bak_c = backup_cost(backup_gb, pricing["backup"])
            total = aggregate_cost(comp, sto_c, net_c, bak_c)
            previous_cpu[w["workload_id"]] = cpu_alloc
            records.append({
                "month": month, "workload": w["workload_id"], "scenario": scenario_name,
                "users": users_t, "cpu_demand": cpu_dem, "allocated_cpu": cpu_alloc,
                "memory_demand": mem_dem, "allocated_memory": mem_alloc,
                "storage_gb": sto_t, "network_gb": net_t, "backup_gb": backup_gb,
                "compute_cost": comp, "storage_cost": sto_c, "network_cost": net_c,
                "backup_cost": bak_c, "total_workload_cost": total,
            })
    return pd.DataFrame(records)
