from __future__ import annotations


def compute_memory_cost(cpu_alloc: float, mem_alloc: float, p_cpu: float, p_mem: float,
                        hours_per_month: float = 730.0) -> float:
    """Implements Equation (3.8)."""
    vals = [cpu_alloc, mem_alloc, p_cpu, p_mem, hours_per_month]
    if any(v < 0 for v in vals):
        raise ValueError("Cost-model inputs must be non-negative.")
    return p_cpu * cpu_alloc * hours_per_month + p_mem * mem_alloc * hours_per_month


def storage_cost(storage_gb: float, p_storage: float) -> float:
    """Implements Equation (3.9)."""
    if storage_gb < 0 or p_storage < 0:
        raise ValueError("Storage values and tariff must be non-negative.")
    return p_storage * storage_gb


def network_cost(network_gb: float, p_network: float) -> float:
    """Implements Equation (3.10)."""
    if network_gb < 0 or p_network < 0:
        raise ValueError("Network values and tariff must be non-negative.")
    return p_network * network_gb


def backup_cost(backup_gb: float, p_backup: float) -> float:
    """Implements Equation (3.11)."""
    if backup_gb < 0 or p_backup < 0:
        raise ValueError("Backup values and tariff must be non-negative.")
    return p_backup * backup_gb


def aggregate_cost(compute: float, storage: float, network: float, backup: float) -> float:
    """Implements the workload contribution inside Equation (3.7)."""
    vals = [compute, storage, network, backup]
    if any(v < 0 for v in vals):
        raise ValueError("Cost components must be non-negative.")
    return sum(vals)
