from __future__ import annotations


def effective_compute_cost(on_demand_cost: float, reserved_fraction: float, discount: float) -> float:
    """Implements Equation (3.23)."""
    if on_demand_cost < 0:
        raise ValueError("On-demand cost cannot be negative.")
    if not (0 <= reserved_fraction <= 1) or not (0 <= discount <= 1):
        raise ValueError("Reserved fraction and discount must be in [0, 1].")
    return (reserved_fraction * (1.0 - discount) + (1.0 - reserved_fraction)) * on_demand_cost
