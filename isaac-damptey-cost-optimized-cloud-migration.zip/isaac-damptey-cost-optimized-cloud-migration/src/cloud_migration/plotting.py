from __future__ import annotations
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt


def _save(fig, base_path: Path) -> None:
    fig.tight_layout()
    fig.savefig(base_path.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base_path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def plot_all(monthly: pd.DataFrame, workloads: pd.DataFrame, anchors: pd.DataFrame,
             cost_drivers: pd.DataFrame, elasticity: pd.DataFrame,
             sensitivity: pd.DataFrame, output_dir: str | Path) -> None:
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    # Fig 4.1
    fig,ax=plt.subplots(figsize=(8,5)); bottom=[0]*len(cost_drivers)
    for col,label in [("compute_pct","Compute"),("storage_pct","Storage"),("network_pct","Network"),("backup_pct","Backup")]:
        ax.bar(cost_drivers["workload"],cost_drivers[col],bottom=bottom,label=label)
        bottom=[a+b for a,b in zip(bottom,cost_drivers[col].tolist())]
    ax.set_title("Distribution of Major Cost Drivers Across University Workloads"); ax.set_xlabel("Workload category"); ax.set_ylabel("Cost contribution (%)"); ax.legend()
    _save(fig,out/"Figure_4_1_Cost_Driver_Distribution")
    # Fig 4.2
    fig,ax=plt.subplots(figsize=(8,5))
    for s in ["Baseline","Hybrid","Optimized"]: ax.plot(monthly["Month"],monthly[s],label=s)
    ax.set_title("Monthly Cost Trend Comparison Across Migration Scenarios"); ax.set_xlabel("Month"); ax.set_ylabel("Monthly cloud cost (USD)"); ax.legend()
    _save(fig,out/"Figure_4_2_Monthly_Cost_Trend")
    # Fig 4.3
    fig,ax=plt.subplots(figsize=(7,5)); labels=["Baseline lift-and-shift","Hybrid limited optimisation","Proposed optimised framework"]; vals=[float(monthly[s].sum()) for s in ["Baseline","Hybrid","Optimized"]]
    bars=ax.bar(labels,vals); ax.set_title("Comparative Three-Year TCO by Migration Strategy"); ax.set_ylabel("Three-year TCO (USD)"); ax.tick_params(axis="x",rotation=15)
    for bar,val in zip(bars,vals): ax.annotate(f"{val:,.2f}",(bar.get_x()+bar.get_width()/2,val),xytext=(0,3),textcoords="offset points",ha="center",fontsize=8)
    _save(fig,out/"Figure_4_3_TCO_Comparison")
    # Fig 4.4
    fig,ax=plt.subplots(figsize=(8,5)); cum=(monthly["Baseline"]-monthly["Optimized"]).cumsum(); hit=int((cum>=12000).idxmax()+1)
    ax.plot(monthly["Month"],cum,label="Cumulative savings"); ax.axhline(12000,linestyle="--",label="Incremental optimisation investment"); ax.axvline(hit,linestyle=":",label=f"Break-even: Month {hit}")
    ax.set_title("Break-Even Curve for the Proposed Migration Framework"); ax.set_xlabel("Month"); ax.set_ylabel("Cumulative savings (USD)"); ax.legend()
    _save(fig,out/"Figure_4_4_Break_Even_Curve")
    # Fig 4.5
    fig,ax=plt.subplots(figsize=(8,5))
    for scenario,g in elasticity.groupby("scenario",sort=False): ax.plot(g["load_change_pct"],g["cost_usd"],marker="o",label=scenario)
    ax.set_title("Cost Elasticity Under Workload Growth"); ax.set_xlabel("Additional workload growth (%)"); ax.set_ylabel("Projected month-36 cost (USD)"); ax.legend()
    _save(fig,out/"Figure_4_5_Cost_Elasticity")
    # Fig 4.6
    plot=sensitivity.copy(); plot["case"]=plot["parameter"]+" — "+plot["setting"]
    fig,ax=plt.subplots(figsize=(8,5)); ax.barh(plot["case"],plot["reported_change_pct"]); ax.axvline(0,linewidth=1); ax.set_title("Sensitivity of Projected Cloud Cost to Key Input Parameters"); ax.set_xlabel("Change in optimized three-year TCO (%)"); ax.set_ylabel("Sensitivity case")
    _save(fig,out/"Figure_4_6_Sensitivity_Analysis")
