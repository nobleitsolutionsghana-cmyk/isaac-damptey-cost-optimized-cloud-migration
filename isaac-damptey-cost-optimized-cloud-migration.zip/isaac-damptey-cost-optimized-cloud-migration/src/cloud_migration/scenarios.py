from __future__ import annotations
from collections.abc import Mapping
from .exceptions import ParameterResolutionError


def unresolved_fields(mapping: Mapping, required: list[str]) -> list[str]:
    return [key for key in required if mapping.get(key) is None]


def validate_scenario_parameters(name: str, scenario: Mapping) -> None:
    if name == "baseline":
        required = ["overprovisioning_factor"]
    elif name == "hybrid":
        required = ["rho_cpu", "rho_mem", "reserved_fraction", "reserved_discount", "hybrid_cloud_fraction"]
    elif name == "optimized":
        required = ["rho_cpu", "rho_mem", "u_low", "u_up", "mu", "zeta", "cpu_min", "cpu_max",
                    "reserved_fraction", "reserved_discount", "classification_thresholds", "strategy_weights"]
    else:
        raise ValueError(f"Unknown scenario: {name}")
    missing = unresolved_fields(scenario, required)
    if missing:
        raise ParameterResolutionError([f"{name}.{x}" for x in missing], f"{name} scenario")
