from __future__ import annotations
import time
import tracemalloc
import pandas as pd
from .workload_model import annual_to_monthly_rate, user_growth, storage_growth, compute_demand, memory_demand, network_demand
from .cost_model import compute_memory_cost, storage_cost, network_cost, backup_cost, aggregate_cost


def synthetic_scalability_run(base_workloads: pd.DataFrame, n_workloads: int, months: int = 36) -> dict:
    """Software-scalability test only; not part of the thesis scientific experiment.

    Uses explicit test-only coefficients solely to exercise computational throughput.
    """
    reps=(n_workloads+len(base_workloads)-1)//len(base_workloads)
    df=pd.concat([base_workloads]*reps,ignore_index=True).iloc[:n_workloads].copy()
    monthly_g=annual_to_monthly_rate(0.05)
    tracemalloc.start(); start=time.perf_counter(); total=0.0; records=0
    for month in range(1,months+1):
        for _,w in df.iterrows():
            users=user_growth(float(w.users),monthly_g,month)
            cpu=compute_demand(float(w.cpu_vcpu),users,float(w.users),0.5)
            mem=memory_demand(float(w.memory_gb),users,float(w.users),0.5)
            sto=storage_growth(float(w.storage_gb),50.0,month)
            net=network_demand(float(w.network_gb_month),users,float(w.users),0.05)
            comp=compute_memory_cost(cpu,mem,0.05,0.01,730)
            total+=aggregate_cost(comp,storage_cost(sto,0.02),network_cost(net,0.08),backup_cost(sto*0.5,0.01))
            records+=1
    elapsed=time.perf_counter()-start; current,peak=tracemalloc.get_traced_memory(); tracemalloc.stop()
    return {"workloads":n_workloads,"months":months,"workload_month_records":records,"runtime_seconds":elapsed,"peak_memory_mb":peak/1024/1024,"test_only_total":total}
