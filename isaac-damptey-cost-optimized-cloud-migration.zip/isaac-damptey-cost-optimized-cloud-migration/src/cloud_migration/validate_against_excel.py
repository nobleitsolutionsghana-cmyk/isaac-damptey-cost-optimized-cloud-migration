from __future__ import annotations
from pathlib import Path
import zipfile
import re


def audit_excel_formula_presence(workbook_path: str | Path) -> dict:
    """Structurally verify that the supplied XLSX contains formula cells.

    This function deliberately avoids pretending to be a headless Excel calculation
    engine. Numerical cross-checks are performed independently in Python and the
    workbook is intended for opening/recalculation in Microsoft Excel or compatible
    software.
    """
    path=Path(workbook_path)
    if not path.exists():
        return {"exists":False,"formula_cells":0,"status":"FAIL"}
    formula_cells=0
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            if name.startswith("xl/worksheets/sheet") and name.endswith(".xml"):
                text=zf.read(name).decode("utf-8",errors="ignore")
                formula_cells += len(re.findall(r"<(?:[A-Za-z0-9_]+:)?f(?:\s|>)", text))
    return {"exists":True,"formula_cells":formula_cells,"status":"PASS" if formula_cells>0 else "FAIL"}
