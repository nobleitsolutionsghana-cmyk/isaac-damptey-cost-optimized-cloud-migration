# Model description

The work examines 5 representative university services and 3 cloud migration scenarios over 36 months using a deterministic cost model. Pricing includes CPU/memory, storage, network egress and backup. The software implements the Chapter Three equations in small tested functions.

## What can actually run?

1. **Available:** reporting reconstruction based on the pre-reported Month 1, 12, 24 and 36 costs plus a known TCO, followed by derived comparisons, figures and tables.
2. **Available:** isolated unit-tested equation functions for workload growth, cloud cost, right-sizing, scaling and discounted compute allocation.
3. **Not independently executable yet:** exact scenario cost generation using the full workload/optimisation parameter set; the necessary coefficients are not recorded in the supplied final thesis.

This repository does not substitute historical record reconstruction for new cloud-model evidence.
