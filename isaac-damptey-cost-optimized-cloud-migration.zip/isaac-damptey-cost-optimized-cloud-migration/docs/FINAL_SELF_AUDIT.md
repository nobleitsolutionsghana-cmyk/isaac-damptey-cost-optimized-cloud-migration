# Final Reproducibility Self-Audit

- Source-code files: **36**
- Test files: **19**
- Pytest result: **...........................                                              [100%]
27 passed in 0.09s**
- Exact thesis-faithful validation checks passed: **15/15**
- Derived-from-reconstructed validation checks passed: **9/9**
- Independently derived validation checks passed: **2/2**
- Excel validation workbook: **PASS** with **491** detected formula cells
- First-principles status: **BLOCKED_BY_UNRESOLVED_SOURCE_PARAMETERS**
- Unresolved first-principles parameters: **22**

## Scientific-integrity conclusion

The package supports exact thesis-faithful reproduction of the documented anchor-constrained monthly trajectories and their TCO/checkpoint constraints. It does not claim full first-principles reproduction because exact scenario/workload coefficients required by Equations 3.2-3.23 are not all preserved in the thesis source.

The displayed TCO values imply Optimized-versus-Hybrid savings of USD 25,016.83, whereas the thesis table reports USD 25,016.84. This one-cent item is retained in the audit rather than concealed.
