# Assumption Register

## A. Representative workload assumptions
The five workload profiles are researcher-defined analytical baselines. They are not live measurements from KNUST, UENR or any other named university.

## B. Provider-informed pricing assumptions
CPU, memory, storage, outbound network and backup rates are simplified provider-informed, provider-agnostic tariffs. The thesis does not preserve one dated provider quotation.

## C. Scenario assumptions
The baseline retains overprovisioning characteristics, the hybrid scenario applies partial rationalisation, and the proposed scenario uses workload-aware right-sizing, controlled auto-scaling and reserved-capacity logic. Exact numerical scenario coefficients are not preserved.

## D. Implementation constants
- 36 months
- 730 billable hours/month
- deterministic execution

## E. Researcher-defined analytical assumptions
Break-even investment thresholds: USD 12,000, USD 8,000 and USD 4,500.

## F. Derived quantities
- monthly-equivalent user growth: `(1 + annual_rate)^(1/12) - 1`
- TCO: sum of 36 monthly costs
- savings and savings percentage
- cumulative savings and break-even
- point/average cost elasticity
- sensitivity percentage change

## G. Chapter Four validation targets
Checkpoint costs, TCOs, cost-driver percentages, load-case costs and alternate sensitivity TCOs are retained in `data/reference/`. Reference values are clearly separated from results independently generated from model equations.
