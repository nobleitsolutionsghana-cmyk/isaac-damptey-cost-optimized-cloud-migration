# Examiner / defence guide

For detailed answers see [`DEFENCE_REPRODUCIBILITY_GUIDE.md`](DEFENCE_REPRODUCIBILITY_GUIDE.md).

**Where did the workload data come from?** They are five researcher-defined representative profiles of LMS, SIS, email, archival and research systems, not real measurements from KNUST, UENR or other universities.

**Were AWS, Azure and GCP actual billed costs used?** No. Five composite tariffs represent provider-informed cost categories and approximate magnitudes; they do not correspond to a particular provider contract, service or region.

**How are the results reproduced?** The final thesis describes a cubic, anchor-constrained monthly reporting reconstruction from four checkpoints and three-year TCO. This code exactly implements that procedure and computes the resulting arithmetic, tables and figures.

**Did the model independently generate the reported TCOs using fully specified resource economics?** No. The source thesis lacks complete exact scenario/workload parameters. The repository includes relevant formula implementations and a deliberate completeness guard, with exact missing source details listed in `UNRESOLVED_PARAMETERS.md`.

**Why use Python, NumPy, Pandas and Matplotlib?** Python enables inspectable numerical functions; NumPy provides deterministic array calculations, Pandas tabulation, and Matplotlib chart generation. Tests are automated with pytest.

**What are the main limitations?** Representative not empirical data; simplified composite tariffs; no live deployment; no measured latency or QoS; missing exact first-principles scenario coefficients; reference-based cost-driver, elasticity-point and sensitivity alternate costs; model-based planning projections rather than guaranteed institutional savings.

**Can examiners check the calculations?** Yes: run `python scripts/reproduce_all.py`, inspect the 36 monthly results and validation report, and run pytest. The Excel workbook offers formula-based arithmetic checks (open/recalculate in Excel).
