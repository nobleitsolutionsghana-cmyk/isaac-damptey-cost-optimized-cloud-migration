# Code provenance and scope

| Source category | File(s) | Evidence / interpretation |
|---|---|---|
| Appendix A code transcription | `legacy/appendix_a_transcribed.py` | Extracted from the supplied August 2026 final thesis DOCX. Syntactically valid Python; text is recovered from the document, **not** an authenticated historical `.py` source file. |
| Modular implementation | `src/cloud_migration/*.py` | Subsequent engineering/reproducibility implementation of thesis equations and reporting logic. Not falsely presented as the originally authored codebase. |
| Thesis-reported figures | `data/reference/` | Values stated in thesis tables and Appendix A; used as **reference targets** or reporting-series inputs, not as evidence of independent first-principles derivation. |
| Representative input profiles | `data/workloads.csv` | Researcher-defined simulation abstractions; no actual university measurements. |
| Model pricing | `data/pricing.csv` | Provider-informed generic assumptions, not live quotations. |
| Unspecified parameters | `config/*.yaml`, `docs/UNRESOLVED_PARAMETERS.md` | Explicit `null` entries prevent unjustified first-principles claims. |

## Distinction between reproducibility claims

- **Thesis-faithful reconstruction**: The four month checkpoints and TCO per scenario are inputs; a cubic plus correction reconstructs all 36 reported monthly costs. Matching those inputs by construction does not independently validate the cloud optimisation framework.
- **First-principles computational model**: The code implements resource-growth, cost and capacity equations, but cannot execute the full thesis scenario simulation until actual numeric coefficients and rules missing from the thesis are supplied with source provenance.
- **Supporting arithmetic**: Savings and break-even follow from reconstructed monthly series; reported elasticity point estimates and most alternative sensitivity TCOs are independent *reference input values*, with their percentages / average elasticities recomputed.

These qualifications should be retained when citing the repository in a thesis defence or publication.
