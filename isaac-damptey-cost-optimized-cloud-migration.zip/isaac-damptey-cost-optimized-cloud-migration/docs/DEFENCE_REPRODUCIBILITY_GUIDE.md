# Defence Reproducibility Guide

## What data were used?
Representative, researcher-defined workload profiles for LMS, SIS, institutional email, file storage/archive and research computing; simplified provider-informed tariffs; and controlled scenario/sensitivity assumptions.

## Are these actual university workload measurements?
No. The thesis explicitly treats them as representative simulation inputs, not production measurements from a named university.

## Why are the workloads representative?
They were designed to produce a controlled heterogeneous portfolio spanning teaching, administration, communication, storage/archival and compute-intensive research roles.

## How were prices specified?
The model uses provider-informed, provider-agnostic rates for CPU, memory, storage, outbound network and backup. They are modelling assumptions, not exact current quotations.

## How are workloads grown over time?
The design equations use compound user growth, linear storage accumulation and user-sensitive compute/memory/network demand. The base user-growth condition is 5% annual equivalent, converted to an equivalent monthly compound rate.

## How are the three scenarios different?
Baseline represents predominantly static lift-and-shift with retained overprovisioning; hybrid uses partial rationalisation/selective cost controls; proposed optimised uses workload-aware classification, right-sizing, controlled auto-scaling and reserved-capacity logic.

## How does right-sizing work?
Allocated CPU and memory equal the ceiling of demand multiplied by a safety margin. Exact thesis safety margins are parameterised but not numerically preserved.

## How does auto-scaling work?
Current CPU demand is compared with previous allocation; threshold rules determine an adjustment factor; allocation is clipped between minimum and maximum CPU bounds. Exact thresholds/factors/bounds are not numerically preserved.

## How does reserved capacity work?
A configurable fraction of on-demand compute cost receives a configurable discount. The thesis does not claim one universal provider discount.

## How is TCO calculated?
The sum of all monthly scenario costs over 36 months.

## How is break-even calculated?
The first month at which cumulative savings relative to a comparator equal or exceed the analytical incremental investment assumption.

## How is elasticity calculated?
The proportional cost change divided by proportional workload change. Average elasticity is calculated from the 10%, 20% and 30% load cases.

## How was sensitivity analysis conducted?
One factor at a time: user growth, storage accumulation, network intensity and pricing. The exact non-price rerun mapping is not fully preserved; the package therefore labels those alternate TCOs as reported reference values.

## How was the model validated?
Formula/unit checks, arithmetic consistency, spreadsheet cross-checks, deterministic reruns, sensitivity checks, boundary checks and traceability from methods to Chapter Four results.

## Why is the simulation deterministic?
No Monte Carlo or stochastic event process was used. Fixed inputs produce fixed outputs.

## Can another researcher reproduce the results?
The reported trajectory/TCO/savings/break-even chain can be reproduced exactly using the thesis's documented anchor-constrained reporting procedure. Complete first-principles reproduction of all Chapter Four results requires missing scenario/workload parameter values that are not preserved in the final thesis.

## Which parameters are assumptions?
Representative workloads, user/storage/network growth conditions, scenario optimisation parameters, provider-informed tariffs and break-even investment thresholds are modelling assumptions or controlled inputs, with provenance recorded in the package.

## What exactly does anchor-constrained interpolation do?
A cubic passes through Months 1, 12, 24 and 36. A polynomial basis that is zero at those four months is added with a coefficient selected so the full 36-month sum equals the stated TCO. The four checkpoints remain unchanged.

## Did interpolation generate the optimisation result?
No. In the thesis it is explicitly a reporting trajectory-construction/consistency step. The package keeps it in a separate module to prevent confusion with the first-principles optimisation equations.

## Can Chapter Four figures and tables be regenerated automatically?
Yes. The one-command script regenerates them. Some figures are generated from reported reference tables because the source coefficients needed to re-derive those tables are not preserved.

## What limitations remain?
The main limitation is incomplete preservation of exact first-principles scenario coefficients. A second, minor numerical consistency issue is the one-cent Optimized-versus-Hybrid savings difference in Table 4.5.
