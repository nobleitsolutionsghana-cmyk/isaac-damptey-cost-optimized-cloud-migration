# Unresolved model parameters

The comprehensive register is [`UNRESOLVED_REPRODUCIBILITY_ITEMS.md`](UNRESOLVED_REPRODUCIBILITY_ITEMS.md). It documents absent intensity coefficients, storage accumulation, network sensitivity, backup allocation, overprovisioning, hybrid fractions, class thresholds, weights, right-sizing margins, scaling bounds and reserved discounts.

These are **not** permissions to pick plausible values silently: obtaining a new set of reasonable assumptions would create a *new numerical experiment*, not historical reproduction of the thesis's specific published result. To make the stronger claim, locate the actual original simulation configuration, dated scripts and input datasets; if unavailable, conduct and report an explicitly labelled new experiment, and update the thesis conclusions accordingly.

`python scripts/run_first_principles.py --scenario optimized` deliberately exits with status 2 and lists unresolved variables until documentation-backed numeric values are provided. Do not change the exit to success by catching and hiding this exception.

**Additional reproducibility boundary:** the baseline static-provisioning interpretation and hybrid deployment-cost accounting require explicit executable policies; see the implementation completeness warning in the full register.
