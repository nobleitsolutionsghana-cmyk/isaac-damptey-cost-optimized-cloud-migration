# Validation Report

This report separates exact thesis-faithful reconstruction from independent first-principles execution. It does not claim that source parameters absent from the thesis were recovered or inferred.

**Thesis-faithful critical checks:** PASS
**Excel formula-structure audit:** PASS (491 formula cells detected)
**First-principles status:** BLOCKED BY UNRESOLVED SOURCE PARAMETERS

## Quantitative validation matrix

| metric | thesis_value | reproduced_value | difference | tolerance | status | reproduction_basis |
| --- | --- | --- | --- | --- | --- | --- |
| TCO Baseline | 162331 | 162331 | 2.91038e-11 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Baseline Month 1 | 3883.35 | 3883.35 | -1.36424e-12 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Baseline Month 12 | 4268.9 | 4268.9 | -9.09495e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Baseline Month 24 | 4704.85 | 4704.85 | 0 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Baseline Month 36 | 5157.9 | 5157.9 | 0 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| TCO Hybrid | 139567 | 139567 | 2.91038e-11 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Hybrid Month 1 | 3320.75 | 3320.75 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Hybrid Month 12 | 3663.71 | 3663.71 | -9.09495e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Hybrid Month 24 | 4050.75 | 4050.75 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Hybrid Month 36 | 4452.17 | 4452.17 | -1.81899e-12 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| TCO Optimized | 114550 | 114550 | 1.45519e-11 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Optimized Month 1 | 2706.62 | 2706.62 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Optimized Month 12 | 3000.18 | 3000.18 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Optimized Month 24 | 3330.63 | 3330.63 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Optimized Month 36 | 3672.46 | 3672.46 | -4.54747e-13 | 0.01 | PASS | Exact thesis-faithful reconstruction |
| Savings amount Optimized vs Baseline | 47781.3 | 47781.3 | 0 | 0.01 | PASS | Derived from reconstructed TCO |
| Savings percent Optimized vs Baseline | 29.43 | 29.4345 | 0.00445615 | 0.01 | PASS | Derived from reconstructed TCO |
| Break-even Optimized vs Baseline | 10 | 10 | 0 | 0 | PASS | Derived from reconstructed monthly series |
| Savings amount Optimized vs Hybrid | 25016.8 | 25016.8 | 0 | 0.01 | PASS | Derived from reconstructed TCO |
| Savings percent Optimized vs Hybrid | 17.92 | 17.9246 | 0.00463977 | 0.01 | PASS | Derived from reconstructed TCO |
| Break-even Optimized vs Hybrid | 13 | 13 | 0 | 0 | PASS | Derived from reconstructed monthly series |
| Savings amount Hybrid vs Baseline | 22764.5 | 22764.5 | 0 | 0.01 | PASS | Derived from reconstructed TCO |
| Savings percent Hybrid vs Baseline | 14.02 | 14.0235 | 0.00347349 | 0.01 | PASS | Derived from reconstructed TCO |
| Break-even Hybrid vs Baseline | 8 | 8 | 0 | 0 | PASS | Derived from reconstructed monthly series |
| Average elasticity Baseline | 1.055 | 1.05491 | -8.63939e-05 | 0.002 | PASS | Average derived from reported load-cost points; load-cost points are reference-only |
| Average elasticity Hybrid | 0.978 | 0.978181 | 0.000180927 | 0.002 | PASS | Average derived from reported load-cost points; load-cost points are reference-only |
| Average elasticity Optimized | 0.902 | 0.902417 | 0.000416606 | 0.002 | PASS | Average derived from reported load-cost points; load-cost points are reference-only |
| Sensitivity change User growth rate 2% annual | -5.26 | -5.26445 | -0.00444899 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change User growth rate 10% annual | 4.09 | 4.08541 | -0.00459197 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Storage growth Low accumulation | -3.72 | -3.72268 | -0.00267522 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Storage growth High accumulation | 5.96 | 5.95627 | -0.00373012 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Network intensity Low traffic | -3.37 | -3.37071 | -0.000706281 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Network intensity High traffic | 4.21 | 4.21337 | 0.00336976 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Pricing variation -10% tariff | -10 | -10 | -1.74596e-06 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Sensitivity change Pricing variation +10% tariff | 10 | 9.99999 | -6.98386e-06 | 0.01 | PASS | Change percentage derived from reported alternate TCO |
| Uniform pricing sensitivity -10% | 103095 | 103095 | 0.002 | 0.01 | PASS | Independently derived under uniform tariff scaling |
| Uniform pricing sensitivity +10% | 126005 | 126005 | 0.008 | 0.01 | PASS | Independently derived under uniform tariff scaling |

## First-principles completeness

Exact first-principles reproduction is deliberately blocked until the following thesis source parameters are supplied:

- `backup_fraction`
- `baseline.overprovisioning_factor`
- `hybrid.hybrid_cloud_fraction`
- `hybrid.reserved_discount`
- `hybrid.reserved_fraction`
- `hybrid.rho_cpu`
- `hybrid.rho_mem`
- `intensity_coefficient`
- `optimized.classification_thresholds`
- `optimized.cpu_max`
- `optimized.cpu_min`
- `optimized.mu`
- `optimized.reserved_discount`
- `optimized.reserved_fraction`
- `optimized.rho_cpu`
- `optimized.rho_mem`
- `optimized.strategy_weights`
- `optimized.u_low`
- `optimized.u_up`
- `optimized.zeta`
- `storage_growth_gb_month`
- `traffic_sensitivity`

See `UNRESOLVED_REPRODUCIBILITY_ITEMS.md` for methodological consequences and required provenance.
