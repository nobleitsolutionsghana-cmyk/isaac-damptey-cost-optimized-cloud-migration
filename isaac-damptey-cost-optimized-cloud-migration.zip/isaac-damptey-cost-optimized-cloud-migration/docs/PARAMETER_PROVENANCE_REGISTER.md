# Parameter Provenance Register

| Symbol / group | Description | Value preserved in thesis | Unit | Scope | Provenance | Thesis location | Required for exact first-principles? | Status |
|---|---|---:|---|---|---|---|---|---|
| CPU/MEM/STO/NET/U | Five workload baselines | yes | mixed | per workload | researcher-defined representative baseline | Table 3.8 | yes | Resolved |
| p_cpu | CPU tariff | 0.05 | USD/vCPU-hour | global | provider-informed modelling assumption | Table 3.10 | yes | Resolved |
| p_mem | Memory tariff | 0.01 | USD/GB-hour | global | provider-informed modelling assumption | Table 3.10 | yes | Resolved |
| p_sto | Storage tariff | 0.02 | USD/GB-month | global | provider-informed modelling assumption | Table 3.10 | yes | Resolved |
| p_net | Network tariff | 0.08 | USD/GB | global | provider-informed modelling assumption | Table 3.10 | yes | Resolved |
| p_bak | Backup tariff | 0.01 | USD/GB | global | provider-informed modelling assumption | Table 3.10 | yes | Resolved |
| H | Billable time | 730 | hours/month | global | implementation constant | Table 3.13 | yes | Resolved |
| T | Horizon | 36 | months | global | controlled baseline | Table 3.13 | yes | Resolved |
| g_base | Base user growth | 5% annual equivalent | annual rate | base condition | controlled assumption | Table 3.13 | yes | Resolved as global condition |
| g_low/g_high | Sensitivity growth | 2% / 10% annual | annual rate | sensitivity | controlled assumption | Table 3.13 | yes | Resolved |
| d_i | Storage accumulation | 50–500 sensitivity range; moderate base | GB/month | mapping unclear | controlled assumption | Table 3.13 | yes | **Partially unresolved** |
| lambda_i | Workload intensity | no numerical values | dimensionless | per workload | model parameter | Eq. 3.1/3.4/3.5 | yes | **Unresolved** |
| eta_i | Traffic sensitivity | range 0.01–0.10; base/mapping not preserved | dimensionless | per workload | controlled/model parameter | Eq. 3.6/Table 3.13 | yes | **Partially unresolved** |
| BAK_i(t) / b_i | Backup volume/fraction | no mapping | GB/fraction | per workload | model parameter | Eq. 3.11 | yes | **Unresolved** |
| thresholds | Classification thresholds | no numerical values | 0–1 | global/class-specific | model parameter | Sec. 3.7.5 | yes | **Unresolved** |
| alpha,beta,gamma | Strategy weights | configurable only | weights | decision model | configurable | Eq. 3.16 | yes | **Unresolved** |
| omega,nu,P_max,G_max,B_t | Objective/constraint parameters | no numerical values | mixed | decision model | configurable | Eqs. 3.13–3.14 | yes for solver-style execution | **Unresolved** |
| rho_cpu,rho_mem | Right-sizing margins | parameterised only | fraction | workload/scenario | scenario parameter | Eqs. 3.18–3.19 | yes | **Unresolved** |
| u_low,u_up,mu_i,zeta_i,bounds | Auto-scaling values | parameterised only | mixed | workload/scenario | scenario parameter | Eqs. 3.20–3.22 | yes | **Unresolved** |
| r_i,delta_i | Reserved-capacity fraction/discount | parameterised only | fraction | workload/scenario | scenario parameter | Eq. 3.23 | yes | **Unresolved** |
| I_opt/base | Break-even investment | 12,000 | USD | comparison | researcher-defined analytical assumption | Table 3.13 | no for cost model; yes for break-even | Resolved |
| I_opt/hybrid | Break-even investment | 8,000 | USD | comparison | researcher-defined analytical assumption | Table 3.13 | no for cost model; yes for break-even | Resolved |
| I_hybrid/base | Break-even investment | 4,500 | USD | comparison | researcher-defined analytical assumption | Table 3.13 | no for cost model; yes for break-even | Resolved |
