# Method-to-Code Traceability Matrix

| Thesis section | Equation/Table/Figure | Concept | Python implementation | Input/config | Generated output | Validation test | Status |
|---|---|---|---|---|---|---|---|
| 3.6.2 | Table 3.8 | Representative workloads | `data_loader.load_workloads` | `data/workloads.csv` | validated workload frame | `test_boundary_conditions.py` | Complete |
| 3.6.4 | Table 3.10 | Provider-informed tariffs | `data_loader.load_pricing` | `data/pricing.csv` | pricing map | `test_cost_model.py` | Complete |
| 3.7.1 | 3.1 | Workload vector | `workload_model.workload_vector` | workload row | vector | equation tests | Complete |
| 3.7.2 | 3.2–3.6 | Dynamic demand | `workload_model.*` | growth coefficients | demand trajectories | workload/storage tests | Code complete; thesis coefficients incomplete |
| 3.7.3 | 3.7–3.12 | Cloud cost/TCO | `cost_model.*`, `metrics.tco` | resources + pricing | cost components/TCO | cost/TCO tests | Code complete; exact source allocations incomplete |
| 3.7.4 | 3.13–3.14 | Objective/constraints | scenario validation + generic score functions | weights/bounds | feasibility logic | scenario tests | Design code present; exact thesis weights/bounds absent |
| 3.7.5 | 3.15 | Resource normalisation | `classification.normalised_resource_scores` | workload table | scores | classification tests | Complete |
| 3.7.5 | Threshold rule | Workload class | `classification.classify_scores` | thresholds | class | classification tests | Numeric thresholds unresolved |
| 3.7.6 | 3.16–3.17 | Strategy selection | `strategy_selection.*` | alpha/beta/gamma | strategy | strategy tests | Numeric weights unresolved |
| 3.7.7 | 3.18–3.19 | Right-sizing | `right_sizing.right_size` | rho_cpu/rho_mem | discrete allocation | right-sizing tests | Numeric margins unresolved |
| 3.7.8 | 3.20–3.22 | Auto-scaling | `autoscaling.*` | thresholds/factors/bounds | scaled allocation | auto-scaling tests | Numeric values unresolved |
| 3.7.9 | 3.23 | Reserved capacity | `reserved_capacity.effective_compute_cost` | r_i/delta_i | discounted compute cost | reserved tests | Numeric values unresolved |
| 3.10.1 | 3.24–3.26 | Reporting trajectory | `reporting_reproduction.generate_anchor_constrained_series` | `scenario_anchors.csv` | 36-month costs | anchor/reproducibility tests | Exact |
| 3.12 | 3.27 | Savings | `metrics.savings_percent` | TCO pair | savings % | savings tests | Exact from reconstructed TCO |
| 3.12 | 3.28 | Break-even | `break_even.break_even_month` | monthly series, threshold | month | break-even tests | Exact |
| 3.12 | 3.29 | Elasticity | `elasticity.*` | load-case costs | point/average elasticity | elasticity tests | Average derivable; load-case costs reference-only |
| 4.3.2 | Table/Figure 4.2/4.1 | Cost drivers | reference dataset + plotting | `cost_drivers_reported.csv` | table/figure | reference integrity test | Reference-only |
| 4.5.1–4.5.4 | Tables 4.3–4.5/Figs 4.2–4.4 | Scenario comparison | reporting reconstruction + metrics | anchors/TCO | exact outputs | chapter4 target tests | Exact thesis-faithful |
| 4.5.5 | Table/Fig 4.6/4.5 | Elasticity | reported load-cost points + formula | elasticity reference | average elasticity | elasticity tests | Partial independent derivation |
| 4.6 | Table/Fig 4.7/4.6 | Sensitivity | reported alternate TCOs + arithmetic | sensitivity reference | sensitivity table/figure | sensitivity tests | Pricing independently derivable; others reference-only |
