# Reproducibility Checklist

- [x] Workload inputs stored outside source code.
- [x] Pricing inputs stored outside source code.
- [x] Thesis checkpoint/TCO reference values isolated in `data/reference/`.
- [x] Equations 3.1–3.29 represented by testable functions where computationally applicable.
- [x] Anchor-constrained reporting reconstruction isolated from first-principles engine.
- [x] No random sampling in thesis-faithful mode.
- [x] Strict missing-parameter checks prevent hidden imputation.
- [x] TCO, savings, break-even and elasticity arithmetic tested.
- [x] Figures 4.1–4.6 regenerated as PNG and PDF.
- [x] Tables 4.1–4.7 exported as CSV and Markdown; Excel workbook included.
- [x] Formula-based Excel validation workbook included.
- [x] Software scalability test separated from scientific experiment.
- [x] Run manifest records versions and hashes.
- [x] One-cent Optimized-vs-Hybrid savings discrepancy documented.
- [ ] Complete first-principles numerical reproduction: **not supportable from the current thesis because parameter values are missing**.
