# Method-to-code traceability

See the full audit: [`METHOD_TO_CODE_TRACEABILITY.md`](METHOD_TO_CODE_TRACEABILITY.md).

| Thesis area | Computational implementation | Reproduction mode | Test evidence |
|---|---|---|---|
| Sec. 3.6, Table 3.8 | `data/workloads.csv`; `data_loader.py` | Representative input | `test_data_loading.py` |
| Sec. 3.6, Table 3.10 | `data/pricing.csv`; `cost_model.py` | Generic modelling tariff | `test_cost_model.py` |
| Secs. 3.7.1–3.7.3 | `workload_model.py`, `cost_model.py` | Formula implementations | `test_workload_growth.py`, `test_cost_model.py` |
| Secs. 3.7.4–3.7.9 | `classification.py`, `strategy_selection.py`, `right_sizing.py`, `autoscaling.py`, `reserved_capacity.py` | Formula implementations; missing exact experimental coefficients | `test_classification.py`, `test_right_sizing.py`, `test_autoscaling.py` |
| Sec. 3.10.1 | `reporting_reproduction.py` | **Thesis-faithful reporting reconstruction** | `test_anchor_reconstruction.py` |
| Secs. 3.11–3.12 | `metrics.py`, `break_even.py`, `elasticity.py`, `sensitivity.py`, `validation.py` | Calculated checks of references and reconstructed series | `test_tco.py`, `test_break_even.py`, `test_elasticity.py` |
| Chapter Four Tables 4.1–4.7 | `scripts/generate_tables.py` | Mixed reference and derived outputs (see Results reproduction) | `test_chapter4_targets.py` |
| Chapter Four Figures 4.1–4.6 | `plotting.py` | Mixed reference and derived outputs (see Results reproduction) | Reproduction smoke command |
