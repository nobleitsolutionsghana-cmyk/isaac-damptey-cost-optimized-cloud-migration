# Parameter provenance

The detailed authoritative parameter inventory is [`PARAMETER_PROVENANCE_REGISTER.md`](PARAMETER_PROVENANCE_REGISTER.md). This short entry explains how to read it.

| Parameter group | Origin | Numeric status |
|---|---|---|
| Five workload profile vectors | Representative researcher-defined inputs | Specified |
| Compute/storage/network/backup tariff vector | Provider-informed, provider-agnostic modelling rates | Specified |
| 36-month horizon and 730 billable hours | Modelling assumption | Specified |
| Reported Month 1/12/24/36 and TCO | Thesis-reported reference outputs | Specified as **targets**, not first-principles inputs |
| Right-sizing margins and scaling triggers | Scenario assumptions | **Not specified sufficiently** for exact scenario rerun |
| Traffic coefficients, backup shares, storage accumulation | Workload assumptions | **Not specified sufficiently** |
| Baseline/hybrid allocation and reserved share/discount | Scenario assumptions | **Not specified sufficiently** |
| Reported sensitivity cases | Thesis-reported reference outputs | Numeric costs specified; independent perturbation configurations incomplete |

Never present a value inferred solely by fitting reported outputs as an independently known research parameter.
