# Thesis-to-Code Audit

This audit maps the computational claims of Chapters Three and Four to executable materials. It also records where the thesis does not preserve enough numerical information for an exact first-principles rerun.

| Thesis element | Computational requirement | Code module / function | Input | Output | Validation |
|---|---|---|---|---|---|
| Eq. 3.1 | Workload vector | `workload_model.workload_vector` | workload attributes | tuple/vector | unit test |
| Eq. 3.2 | Compound user growth | `workload_model.user_growth` | users, monthly-equivalent growth, month | users(t) | `test_workload_growth.py` |
| Eq. 3.3 | Storage accumulation | `workload_model.storage_growth` | storage, d_i, month | storage(t) | `test_storage_growth.py` |
| Eq. 3.4 | CPU demand | `workload_model.compute_demand` | CPU baseline, users(t), lambda_i | CPU demand | equation test |
| Eq. 3.5 | Memory demand | `workload_model.memory_demand` | memory baseline, users(t), lambda_i | memory demand | equation test |
| Eq. 3.6 | Network demand | `workload_model.network_demand` | network baseline, users(t), eta_i | network demand | equation test |
| Eq. 3.7 | Scenario monthly aggregation | `cost_model.aggregate_cost` / `simulation.run_first_principles` | component costs | monthly total | cost-model tests |
| Eq. 3.8 | CPU + memory cost | `cost_model.compute_memory_cost` | allocated resources, tariffs, 730 hours | compute cost | cost-model tests |
| Eq. 3.9 | Storage cost | `cost_model.storage_cost` | GB, tariff | storage cost | cost-model tests |
| Eq. 3.10 | Network cost | `cost_model.network_cost` | GB, tariff | network cost | cost-model tests |
| Eq. 3.11 | Backup cost | `cost_model.backup_cost` | BAK_i(t), tariff | backup cost | cost-model tests; BAK mapping unresolved |
| Eq. 3.12 | 36-month TCO | `metrics.tco` | monthly costs | TCO | `test_tco.py` |
| Eqs. 3.13–3.14 | Design objective/constraints | parameter validation and scenario engine | cost, performance/governance parameters | feasible comparison logic | exact weights/bounds unresolved |
| Eq. 3.15 | Normalised resource scores | `classification.normalised_resource_scores` | workload table | CPU/storage/network scores | classification tests |
| Eqs. 3.16–3.17 | Composite strategy score | `strategy_selection.composite_score`, `select_minimum_score` | normalised cost/penalties, alpha/beta/gamma | chosen strategy | strategy tests; thesis weights unresolved |
| Eqs. 3.18–3.19 | Right-sizing | `right_sizing.right_size` | demand, safety margins | allocated CPU/memory | right-sizing tests; thesis margins unresolved |
| Eqs. 3.20–3.22 | Auto-scaling | `autoscaling.*` | current demand, prior allocation, thresholds/factors/bounds | scaled CPU | auto-scaling tests; thesis numeric parameters unresolved |
| Eq. 3.23 | Reserved capacity | `reserved_capacity.effective_compute_cost` | on-demand cost, r_i, delta_i | effective cost | reserved-capacity tests; thesis r_i/delta_i unresolved |
| Eqs. 3.24–3.26 | Anchor-constrained trajectory | `reporting_reproduction.generate_anchor_constrained_series` | reported checkpoint costs and TCO | exact 36-month reporting series | anchor tests |
| Eq. 3.27 | Percentage savings | `metrics.savings_percent` | TCO pair | percentage | savings tests |
| Eq. 3.28 | Break-even | `break_even.break_even_month` | monthly series, investment | first crossing month | break-even tests |
| Eq. 3.29 | Cost elasticity | `elasticity.point_elasticity`, `average_elasticity` | reported/load-case costs | elasticity | elasticity tests |
| Table 4.1 | Workload profiles | `data/workloads.csv` / table generation | representative baselines | CSV/Excel table | input validation |
| Table 4.2 | Cost-driver percentages | reference table / figure generation | reported percentages | table + Figure 4.1 | **reference-only** because utilisation/backup mapping is missing |
| Table 4.3 | Selected monthly costs | anchor reconstruction | checkpoint/TCO constraints | exact selected-month values | exact tests |
| Table 4.4 | TCO comparison | anchor reconstruction + TCO sum | monthly series | TCO table | exact tests |
| Table 4.5 | Savings & break-even | `metrics` + `break_even` | TCO/monthly series | savings/break-even | exact arithmetic; one-cent table discrepancy recorded |
| Table 4.6 | Elasticity | average recomputed from reported load-case costs | reference load-cost points | elasticity table | average calculation verified; load-case costs reference-only |
| Table 4.7 | Sensitivity | change arithmetic from reported alternate TCOs; pricing ±10 derived | reported alternate TCOs | sensitivity table | percentages verified; non-price alternate TCOs reference-only |
| Figures 4.1–4.6 | Plot directly from generated/reported data with explicit status | `plotting.plot_all` | output tables | PNG/PDF | file existence + deterministic checks |

## Audit conclusion

The final thesis provides exact numerical constraints for the reporting reconstruction and enough information to reproduce the checkpoint/TCO/savings/break-even chain. It does not preserve the complete coefficient set required to regenerate all Chapter Four outputs from Equations (3.1)–(3.23) alone. The package therefore separates exact reporting reproduction from incomplete first-principles reproduction rather than hiding the gap.
