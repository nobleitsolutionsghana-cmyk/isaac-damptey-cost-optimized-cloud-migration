# Simulation assumptions and evidence type

- **Representative input:** workload categories, CPU/memory/storage/network/users in `data/workloads.csv`; manually selected for heterogeneous university-service illustrations.
- **Provider-informed generic model tariffs:** prices and 730 h/month in `data/pricing.csv` and `config/base.yaml`, not live provider-region prices or purchase quotes.
- **Reported results:** checkpoint costs, TCO, cost-driver distributions, sensitivity alternate TCOs and elasticity load-cost points under `data/reference/`.
- **Investment thresholds:** USD 12,000, USD 8,000 and USD 4,500 for the three break-even comparisons; researcher-defined assumptions, not bills.
- **Time horizon:** 36 months; **growth:** 5% nominal annual base for the specified conceptual demand model, with monthly-equivalent compounding.
- **Unresolved source assumptions:** coefficients, threshold choices and scenario treatment rules needed for exact model-from-inputs replication; see `UNRESOLVED_PARAMETERS.md`.
- **Software-only test coefficients:** synthetic scalability test uses explicitly labelled illustrative constants; results are separate from thesis evidence.

No measured post-migration savings, application latency, cloud availability, live university infrastructure survey or institution-specific empirical observations are claimed.
