# Unresolved Reproducibility Items

The following source gaps prevent a defensible claim of complete first-principles reproduction. They are not silently filled.

| Missing parameter/rule | Required by | Consequence | Thesis-faithful reproduction still possible? | What must be specified for full first-principles reproduction |
|---|---|---|---|---|
| Workload intensity `lambda_i` for each workload | Eqs. 3.4–3.5 | CPU/memory demand trajectories cannot be regenerated exactly | Yes | Per-workload numerical coefficients and provenance |
| Traffic sensitivity `eta_i` base and workload mapping | Eq. 3.6 | Network trajectory cannot be regenerated exactly | Yes | Exact base values and mapping; low/high application rule |
| Storage accumulation `d_i` base and per-workload mapping | Eq. 3.3 | Storage/backup growth and sensitivity cannot be regenerated exactly | Yes | Base values and explicit low/high mapping across workloads |
| Backup volume rule / backup fraction | Eq. 3.11 | Backup cost and Table 4.2 percentages cannot be regenerated | Yes | `BAK_i(t)` rule or per-workload backup fraction |
| Baseline overprovisioning/static allocation coefficient | Table 3.3/3.12 | Baseline first-principles monthly costs cannot be recreated | Yes | Exact source-to-cloud allocation factor/rule |
| Hybrid partial rationalisation coefficients and mixed-deployment shares | Table 3.3/3.12 | Hybrid first-principles monthly costs cannot be recreated | Yes | Exact right-sizing/migration fractions and cost-control rules |
| Classification thresholds | Sec. 3.7.5 | Threshold-based classes cannot be independently re-derived exactly | Yes | Threshold values and tie/mixed rule |
| Strategy weights `alpha,beta,gamma` and performance/governance inputs | Eqs. 3.16–3.17 | Strategy score cannot be run as a numerical selector | Yes | Exact weights and normalised penalty/governance values |
| Right-sizing margins `rho_cpu`, `rho_mem` | Eqs. 3.18–3.19 | Optimised allocations cannot be regenerated | Yes | Scenario/workload margins |
| Auto-scaling `u_low,u_up,mu_i,zeta_i,CPU_min,CPU_max` | Eqs. 3.20–3.22 | Month-to-month scaling cannot be regenerated | Yes | Exact scenario/workload values |
| Reserved capacity `r_i,delta_i` | Eq. 3.23 | Effective compute cost cannot be regenerated | Yes | Per-workload/scenario committed fraction and discount |
| Exact transformation used to create Table 4.2 cost-driver shares | Table 4.2 | Cost-driver percentages remain reported reference values | Yes | Utilisation/traffic/backup coefficients and workload-level first-month totals |
| Exact workload perturbation mechanism behind Table 4.6 load-cost points | Table 4.6 | +10/+20/+30 cost points cannot be regenerated from workload model | Yes; average elasticity can be recomputed from reported points | Explicit rule defining which resource demands are multiplied and how scenario provisioning responds |
| Exact non-pricing sensitivity rerun mapping | Table 4.7 | User/storage/network alternate TCOs remain reported reference values | Yes | Explicit base/low/high values per workload and scenario treatment |

## Numerical consistency item
The reported TCOs imply `139,566.71 - 114,549.88 = 25,016.83`, while Table 4.5 reports **USD 25,016.84** for Optimized versus Hybrid savings. The package preserves the thesis-reported table as a validation target where needed but flags the one-cent arithmetic difference. Unless higher-precision unrounded TCO values exist in the original simulation logs, the internally consistent value from the displayed TCOs is **USD 25,016.83**.

## Implementation completeness warning

In addition to the numeric parameters above, the thesis does not establish a fully specified programmatic mapping for some scenario treatment choices. The modular `run_first_principles` function is therefore an **equation demonstrator under explicit parameters**, not a certified executable copy of the historical scenario-allocation algorithm. In particular, the `hybrid_cloud_fraction` field does not on its own define private/retained-infrastructure billing, and the `strategy_weights`/`classification_thresholds` design functions are not a substitute for proof of the specific assignments used to compute the Chapter Four totals. Filling the listed numbers alone does not automatically authenticate the historical simulation.
