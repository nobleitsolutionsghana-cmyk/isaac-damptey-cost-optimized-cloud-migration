# Computational equations and source mapping

| Thesis equations | Purpose | Implementation |
|---|---|---|
| 3.1–3.6 | Workload state and temporal demand | `src/cloud_migration/workload_model.py` |
| 3.7–3.12 | Component costs and total cost of ownership | `src/cloud_migration/cost_model.py`, `metrics.py` |
| 3.13–3.14 | Design-level objective / capacity feasibility (no solver claimed) | `strategy_selection.py`, `right_sizing.py`, `simulation.py` |
| 3.15 | Portfolio resource score normalisation | `classification.py` |
| 3.16–3.17 | Composite strategy score | `strategy_selection.py` |
| 3.18–3.19 | Resource right-sizing | `right_sizing.py` |
| 3.20–3.22 | Utilisation / control scaling | `autoscaling.py` |
| 3.23 | Reserved-capacity price adjustment | `reserved_capacity.py` |
| 3.24–3.26 | **Anchor-constrained reporting trajectory** | `reporting_reproduction.py` |
| 3.27 | Percentage savings | `metrics.py` |
| 3.28 | Break-even | `break_even.py` |
| 3.29 | Workload-cost elasticity | `elasticity.py` |

See the fuller `METHOD_TO_CODE_TRACEABILITY.md`. The existence of a defined mathematical formula does not by itself show that its parameters were supplied for every experiment.
