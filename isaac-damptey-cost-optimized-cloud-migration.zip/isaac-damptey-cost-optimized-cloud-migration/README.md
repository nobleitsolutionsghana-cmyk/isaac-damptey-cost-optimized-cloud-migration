# Cost-Optimized Cloud Migration for Public Universities

**Research software and reproducibility materials** for the MPhil thesis:

*Design and Simulation-Based Evaluation of a Cost-Optimized Cloud Migration Framework for Public Universities*  
**Isaac Damptey** · Department of Information Technology and Decision Sciences · University of Energy and Natural Resources (UENR), Sunyani, Ghana · 2026

> **Reproducibility notice:** This repository distinguishes **thesis-faithful reconstruction** from **first-principles simulation**. The former is executable with the available source inputs. The latter remains blocked by documented missing scenario/workload coefficients. The repository does **not** assert that reconstructed monthly costs were independently predicted by the optimisation model. See [Results reproduction](docs/RESULTS_REPRODUCTION.md) and [Source provenance](docs/SOURCE_PROVENANCE.md).

## Overview

The study examines pre-migration cloud cost planning for public universities using five representative workload categories, a provider-informed composite price schedule, and three migration planning strategies. The research adopts Design Science Research and a deterministic 36-month evaluation. No named institution's operational traces, bills, confidential student records or live cloud migration were used.

**Study pipeline:** workload profiling → migration strategy comparison → compute/storage/network/backup cost modelling → right-sizing, conditional auto-scaling and reserved-capacity design rules → TCO, savings, break-even, elasticity and sensitivity evaluation.

### Source inputs

| Workload | vCPU | RAM (GB) | Storage (GB) | Egress (GB/month) | Users |
|---|---:|---:|---:|---:|---:|
| Learning Management System | 16 | 64 | 2,000 | 500 | 5,000 |
| Student Information System | 8 | 32 | 500 | 200 | 3,000 |
| Institutional email | 4 | 16 | 1,000 | 300 | 4,000 |
| File storage / archival | 2 | 8 | 5,000 | 100 | 2,000 |
| Research computing | 32 | 128 | 2,000 | 400 | 500 |

These are **representative researcher-defined workloads**, not production measurements.

## Scenarios

1. **Baseline — lift-and-shift:** predominantly static, unoptimised allocation.
2. **Hybrid — limited optimisation:** selective rationalisation and mixed deployment.
3. **Proposed optimised framework:** workload-aware right-sizing, controlled scaling and reserved-capacity design logic.

The thesis does not disclose all the numeric parameters required to calculate the three scenario cost trajectories independently from workload-level equations. See [Unresolved parameters](docs/UNRESOLVED_PARAMETERS.md).

## Reported results (thesis reference values)

| Scenario | Reported 36-month TCO (USD) |
|---|---:|
| Baseline lift-and-shift | **162,331.18** |
| Hybrid limited optimisation | **139,566.71** |
| Proposed optimised framework | **114,549.88** |

The reported relative savings are **29.43%** versus baseline and **17.92%** versus hybrid. These values are model-based planning projections, **not observed financial savings**. The displayed TCOs imply USD **25,016.83** optimised-versus-hybrid savings, while the thesis reports USD 25,016.84; the discrepancy is flagged.

## Setup

The pinned installation environment supports Python **3.10–3.12**; the thesis reports Python **3.10.13**. Use Python 3.10 when available. The build session may use a newer runtime for smoke testing, but that does not establish a clean pinned install under that runtime.

```bash
# Clone after publishing to your own GitHub account
# git clone https://github.com/<account>/isaac-damptey-cost-optimized-cloud-migration.git
cd isaac-damptey-cost-optimized-cloud-migration
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
```

Alternatively use `conda env create -f environment.yml && conda activate isaac-damptey-cloud-repro`.

## Reproduce the thesis results

```bash
python scripts/reproduce_all.py
python -m pytest -q
```

`reproduce_all.py` generates **the thesis-faithful reporting trajectory**, tables and six figures, computes savings and break-even, runs cross-checks and tests, audits the Excel workbook, and writes reproducibility evidence. It also conducts a strict **first-principles completeness audit**, which identifies missing source parameters rather than guessing them. The command succeeds if its accurately labelled, reproducible targets pass; it does **not** claim the first-principles results are complete.

```bash
python scripts/reproduce_reported_thesis.py        # Reporting reconstruction only
python scripts/generate_tables.py                 # Tables 4.1–4.7, CSV/Markdown/XLSX
python scripts/generate_figures.py                # Figures 4.1–4.6, PNG/PDF
python scripts/run_sensitivity.py --parameter pricing
python scripts/run_first_principles.py --scenario optimized  # Expected blocked status until parameters supplied
python scripts/run_scalability_test.py            # Test-only artificial workloads; NOT thesis science
```

## Repository contents

| Folder | Purpose |
|---|---|
| `src/cloud_migration/` | Tested modular workload/cost/decision/metric code |
| `scripts/` | Execution entry points and one-command runner |
| `data/` | Representative source inputs and **separated** thesis reference results |
| `config/` | Scenario settings, including unresolved parameters as explicit `null` |
| `legacy/` | Appendix A code transcribed from the final thesis |
| `notebooks/` | Explanatory Jupyter notebooks importing modules |
| `tests/` | Python test suite |
| `outputs/` | Reproducible tables, figures, validation reports and logs |
| `validation/` | Formula-based Excel cross-check workbook |
| `docs/` | Equations, provenance, mapping, limitations and defence guide |

## Interpretation of figures and sensitivity results

- **Figure 4.2** and cumulative break-even derive from the documented cubic **anchor-constrained reporting reconstruction** (input: Month 1, 12, 24 and 36 checkpoints and total TCO).
- **Figure 4.1** uses **thesis-reported** workload cost-driver shares because full workload-level pricing/scenario parameters are not preserved.
- **Figure 4.5** plots **thesis-reported** load-cost points, then recalculates their elasticity arithmetic.
- **Figure 4.6** plots **thesis-reported** sensitivity TCOs and percentage changes; pricing ±10% arithmetic can be independently checked under uniform scaling.

See [Reproducibility procedures](REPRODUCIBILITY.md) and [Validation report](docs/VALIDATION_REPORT.md) for test-by-test evidence.

## Citation, licence and release

Use the **Cite this repository** control, enabled by `CITATION.cff`, and cite the thesis where appropriate. No DOI or GitHub URL is claimed until created. Source-code files are MIT-licensed; thesis content and third-party sources are not automatically covered. Please verify ownership and institutional permission before a public release.

To publish the repository, follow [GitHub Upload Guide](GITHUB_UPLOAD_GUIDE.md). For questions about the experimental record, start with [Source provenance](docs/SOURCE_PROVENANCE.md) and [Unresolved parameters](docs/UNRESOLVED_PARAMETERS.md).
