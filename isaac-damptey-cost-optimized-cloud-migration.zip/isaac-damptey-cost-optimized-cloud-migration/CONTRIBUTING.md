# Contributing

This is a thesis reproduction archive. Please preserve the distinction between **thesis-reported reference values**, **reporting reconstruction**, and **genuine first-principles outputs**.

Open a GitHub issue before changing mathematical conventions, units, rounding or parameters. For code changes, add equation-linked tests, explain the source/provenance of every new numerical assumption, and run `python -m pytest -q` and `python scripts/reproduce_all.py`. Never edit `data/reference/` to hide a mismatch; describe corrections explicitly. Missing scientific parameters may only be resolved with documented authoritative research evidence.

Do not upload confidential institutional data, credentials, private logs or student records. Pull requests should remain small and cite the relevant thesis section in their description.
