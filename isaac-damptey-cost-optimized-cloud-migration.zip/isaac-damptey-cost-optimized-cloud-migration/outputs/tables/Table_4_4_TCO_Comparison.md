| Migration scenario | Three-year TCO (USD) | Relative to baseline (%) |
| --- | --- | --- |
| Baseline lift-and-shift | 162331.18 | 100.0 |
| Hybrid limited optimisation | 139566.71 | 85.98 |
| Proposed optimised framework | 114549.88 | 70.57 |
