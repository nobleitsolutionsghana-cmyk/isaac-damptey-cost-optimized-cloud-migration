| Scenario | Base month-36 cost (USD) | Cost at +10% load | Cost at +20% load | Cost at +30% load | Average elasticity |
| --- | --- | --- | --- | --- | --- |
| Baseline | 5157.9 | 5700.8 | 6246.17 | 6793.82 | 1.0549 |
| Hybrid | 4452.17 | 4888.06 | 5323.16 | 5757.54 | 0.9782 |
| Optimized | 3672.46 | 4005.2 | 4335.22 | 4662.78 | 0.9024 |
