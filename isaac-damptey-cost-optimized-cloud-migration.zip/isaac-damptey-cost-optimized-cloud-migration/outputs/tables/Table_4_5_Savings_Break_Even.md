| Comparison | Three-year savings (USD) | Savings (%) | Incremental investment assumption (USD) | Break-even month |
| --- | --- | --- | --- | --- |
| Optimized versus baseline | 47781.3 | 29.4345 | 12000 | 10 |
| Optimized versus hybrid | 25016.83 | 17.9246 | 8000 | 13 |
| Hybrid versus baseline | 22764.47 | 14.0235 | 4500 | 8 |
