| workload_name | cpu_vcpu | memory_gb | storage_gb | network_gb_month | users |
| --- | --- | --- | --- | --- | --- |
| Learning Management System (LMS) | 16 | 64 | 2000 | 500 | 5000 |
| Student Information System (SIS) | 8 | 32 | 500 | 200 | 3000 |
| Institutional email | 4 | 16 | 1000 | 300 | 4000 |
| File storage / archive | 2 | 8 | 5000 | 100 | 2000 |
| Research computing | 32 | 128 | 2000 | 400 | 500 |
