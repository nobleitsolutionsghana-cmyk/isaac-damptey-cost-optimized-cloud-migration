| Parameter | Low setting | Low TCO (USD) | Change from base low (%) | High setting | High TCO (USD) | Change from base high (%) |
| --- | --- | --- | --- | --- | --- | --- |
| User growth rate | 2% annual | 108519.46 | -5.26 | 10% annual | 119229.71 | 4.09 |
| Storage growth | Low accumulation | 110285.56 | -3.72 | High accumulation | 121372.78 | 5.96 |
| Network intensity | Low traffic | 110688.74 | -3.37 | High traffic | 119376.29 | 4.21 |
| Pricing variation | -10% tariff | 103094.89 | -10.0 | +10% tariff | 126004.86 | 10.0 |
