| workload | compute_pct | storage_pct | network_pct | backup_pct | dominant_pattern | status |
| --- | --- | --- | --- | --- | --- | --- |
| LMS | 50.5 | 5.5 | 41.2 | 2.7 | Mixed compute-network profile with strong network sensitivity | reported reference; not independently regenerated from missing utilisation coefficients |
| SIS | 83.4 | 3.5 | 11.3 | 1.8 | Compute-led transactional workload | reported reference; not independently regenerated from missing utilisation coefficients |
| Email | 49.1 | 6.8 | 40.7 | 3.4 | Mixed communication workload with sustained network pressure | reported reference; not independently regenerated from missing utilisation coefficients |
| Storage | 14.3 | 54.3 | 4.3 | 27.1 | Storage-dominant workload with substantial backup burden | reported reference; not independently regenerated from missing utilisation coefficients |
| Research | 93.0 | 2.3 | 3.6 | 1.1 | Strongly compute-dominant workload | reported reference; not independently regenerated from missing utilisation coefficients |
