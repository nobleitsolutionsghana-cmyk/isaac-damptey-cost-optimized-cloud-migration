"""GitHub documented one-command entry point.

Runs the independently validated thesis-faithful reconstruction, tests,
reported-result comparisons and first-principles parameter-completeness audit.
"""
from __future__ import annotations
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name('reproduce_everything.py')), run_name='__main__')
