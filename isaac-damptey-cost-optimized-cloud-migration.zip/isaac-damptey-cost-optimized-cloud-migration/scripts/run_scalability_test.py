from common import ROOT
import pandas as pd
from cloud_migration.scalability import synthetic_scalability_run
base=pd.read_csv(ROOT/"data/workloads.csv")
rows=[synthetic_scalability_run(base,n) for n in [5,25,50,100]]
out=pd.DataFrame(rows); out.to_csv(ROOT/"outputs/validation/software_scalability_test.csv",index=False); print(out.to_string(index=False))
print("NOTE: This is a software scalability test with test-only coefficients; it is not a Chapter Four experiment.")
