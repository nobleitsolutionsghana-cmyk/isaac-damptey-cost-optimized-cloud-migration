from common import ROOT
import argparse
import pandas as pd
from cloud_migration.sensitivity import uniform_pricing_sensitivity, percent_change
parser=argparse.ArgumentParser(); parser.add_argument("--parameter",choices=["pricing","user_growth","storage","network"],default="pricing"); args=parser.parse_args()
base=114549.88
if args.parameter=="pricing":
    for frac in [-0.10,0.10]:
        tco=uniform_pricing_sensitivity(base,frac); print(f"{frac:+.0%}: TCO={tco:,.2f}, change={percent_change(base,tco):+.2f}%")
else:
    df=pd.read_csv(ROOT/"data/reference/sensitivity_reported.csv")
    key={"user_growth":"User growth rate","storage":"Storage growth","network":"Network intensity"}[args.parameter]
    print(df[df.parameter==key].to_string(index=False))
    print("These alternate TCOs are reported reference values. Exact first-principles rerun is blocked because the thesis does not preserve the complete parameter mapping/base settings.")
