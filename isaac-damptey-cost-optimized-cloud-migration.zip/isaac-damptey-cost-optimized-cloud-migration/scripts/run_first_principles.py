from common import ROOT
import argparse
from cloud_migration.simulation import run_first_principles
from cloud_migration.exceptions import ParameterResolutionError

parser=argparse.ArgumentParser()
parser.add_argument("--scenario",choices=["baseline","hybrid","optimized"],default="optimized")
args=parser.parse_args()
try:
    df=run_first_principles(
        ROOT/"data/workloads.csv",ROOT/"data/pricing.csv",ROOT/"config/base.yaml",
        ROOT/f"config/{args.scenario}.yaml")
    out=ROOT/f"outputs/raw/first_principles_{args.scenario}.csv"; df.to_csv(out,index=False)
    print(out)
except ParameterResolutionError as exc:
    print("FIRST-PRINCIPLES EXECUTION BLOCKED BY UNRESOLVED SOURCE PARAMETERS")
    for item in exc.missing: print(" -",item)
    raise SystemExit(2)
