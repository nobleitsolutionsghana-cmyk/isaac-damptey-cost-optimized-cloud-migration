from common import ROOT
from cloud_migration.validation import build_validation_rows

rows = build_validation_rows(ROOT / 'data/reference')
out=ROOT / 'outputs/validation/validation_results.csv'
out.parent.mkdir(parents=True, exist_ok=True)
rows.to_csv(out,index=False)
print(rows[['metric','status','reproduction_basis']].to_string(index=False))
print('Output:',out)
# Only exact reconstructable and independently calculable targets are gating.
critical=rows.reproduction_basis.str.startswith(('Exact thesis-faithful','Derived from reconstructed','Independently derived'))
raise SystemExit(1 if (rows.loc[critical,'status']=='FAIL').any() else 0)
