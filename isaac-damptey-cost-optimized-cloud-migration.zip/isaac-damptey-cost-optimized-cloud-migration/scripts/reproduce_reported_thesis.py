from common import ROOT
import pandas as pd
from cloud_migration.reporting_reproduction import reconstruct_all
from cloud_migration.metrics import tco, savings_percent
from cloud_migration.break_even import break_even_month

anchors=pd.read_csv(ROOT/"data/reference/scenario_anchors.csv")
monthly=reconstruct_all(anchors)
(ROOT/"outputs/raw").mkdir(parents=True,exist_ok=True)
monthly.to_csv(ROOT/"outputs/raw/monthly_costs_thesis_faithful.csv",index=False,float_format="%.8f")
print("Thesis-faithful reconstruction complete.")
for s in ["Baseline","Hybrid","Optimized"]:
    print(f"{s} TCO: {tco(monthly[s]):,.2f}")
print("Optimized vs baseline savings %:",round(savings_percent(tco(monthly.Optimized),tco(monthly.Baseline)),4))
print("Break-even optimized vs baseline:",break_even_month(monthly.Baseline,monthly.Optimized,12000))
