"""Run optimized first-principles model with strict source-parameter checks."""
import subprocess
import sys
from pathlib import Path
cmd=[sys.executable,str(Path(__file__).with_name('run_first_principles.py')),'--scenario','optimized']
raise SystemExit(subprocess.call(cmd))
