from common import ROOT
import pandas as pd
from cloud_migration.reporting_reproduction import reconstruct_all
from cloud_migration.metrics import savings_percent
from cloud_migration.break_even import break_even_month
from cloud_migration.elasticity import average_elasticity

out=ROOT/"outputs/tables"; out.mkdir(parents=True,exist_ok=True)
work=pd.read_csv(ROOT/"data/workloads.csv")
anchors=pd.read_csv(ROOT/"data/reference/scenario_anchors.csv")
monthly=reconstruct_all(anchors)
cost=pd.read_csv(ROOT/"data/reference/cost_drivers_reported.csv")
elas=pd.read_csv(ROOT/"data/reference/elasticity_reported.csv")
sens=pd.read_csv(ROOT/"data/reference/sensitivity_reported.csv")
# Table 4.1
cols=["workload_name","cpu_vcpu","memory_gb","storage_gb","network_gb_month","users"]
t1=work[cols].copy(); t1.to_csv(out/"Table_4_1_Representative_Workloads.csv",index=False)
# Table 4.2
t2=cost.copy(); t2.to_csv(out/"Table_4_2_Cost_Drivers.csv",index=False)
# Table 4.3
t3=monthly[monthly.Month.isin([1,12,24,36])].copy(); t3[["Baseline","Hybrid","Optimized"]]=t3[["Baseline","Hybrid","Optimized"]].round(2); t3.to_csv(out/"Table_4_3_Monthly_Cost_Snapshot.csv",index=False)
# Table 4.4
base=float(anchors.loc[anchors.scenario=="Baseline","tco_usd"].iloc[0]); hyb=float(anchors.loc[anchors.scenario=="Hybrid","tco_usd"].iloc[0]); opt=float(anchors.loc[anchors.scenario=="Optimized","tco_usd"].iloc[0])
t4=pd.DataFrame([{"Migration scenario":"Baseline lift-and-shift","Three-year TCO (USD)":base,"Relative to baseline (%)":100.0},{"Migration scenario":"Hybrid limited optimisation","Three-year TCO (USD)":hyb,"Relative to baseline (%)":hyb/base*100},{"Migration scenario":"Proposed optimised framework","Three-year TCO (USD)":opt,"Relative to baseline (%)":opt/base*100}]); t4.to_csv(out/"Table_4_4_TCO_Comparison.csv",index=False,float_format="%.2f")
# Table 4.5 - arithmetic from reported TCOs, with explicit one-cent audit note on optimized-vs-hybrid
comparisons=[("Optimized versus baseline",base-opt,savings_percent(opt,base),12000,break_even_month(monthly.Baseline,monthly.Optimized,12000)),("Optimized versus hybrid",hyb-opt,savings_percent(opt,hyb),8000,break_even_month(monthly.Hybrid,monthly.Optimized,8000)),("Hybrid versus baseline",base-hyb,savings_percent(hyb,base),4500,break_even_month(monthly.Baseline,monthly.Hybrid,4500))]
t5=pd.DataFrame(comparisons,columns=["Comparison","Three-year savings (USD)","Savings (%)","Incremental investment assumption (USD)","Break-even month"]); t5.to_csv(out/"Table_4_5_Savings_Break_Even.csv",index=False,float_format="%.4f")
# Table 4.6 - reported load cost points, average recomputed
records=[]
for scenario,g in elas.groupby("scenario",sort=False):
    g=g.sort_values("load_change_pct"); basec=float(g.iloc[0].cost_usd); changed=[float(g[g.load_change_pct==x].cost_usd.iloc[0]) for x in [10,20,30]]
    records.append([scenario,basec,*changed,average_elasticity(basec,changed,[.1,.2,.3])])
t6=pd.DataFrame(records,columns=["Scenario","Base month-36 cost (USD)","Cost at +10% load","Cost at +20% load","Cost at +30% load","Average elasticity"]); t6.to_csv(out/"Table_4_6_Cost_Elasticity.csv",index=False,float_format="%.4f")
# Table 4.7 reshape
pairs=[]
for param,g in sens.groupby("parameter",sort=False):
    low=g.iloc[0]; high=g.iloc[1]
    pairs.append([param,low.setting,low.tco_usd,low.reported_change_pct,high.setting,high.tco_usd,high.reported_change_pct])
t7=pd.DataFrame(pairs,columns=["Parameter","Low setting","Low TCO (USD)","Change from base low (%)","High setting","High TCO (USD)","Change from base high (%)"]); t7.to_csv(out/"Table_4_7_Sensitivity.csv",index=False)
# lightweight markdown exports without an extra dependency
for path in out.glob("Table_4_*.csv"):
    df=pd.read_csv(path)
    headers=[str(c) for c in df.columns]
    lines=["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"]*len(headers)) + " |"]
    for row in df.itertuples(index=False,name=None):
        lines.append("| " + " | ".join(str(x) for x in row) + " |")
    (out/(path.stem+".md")).write_text("\n".join(lines)+"\n",encoding="utf-8")
print("Chapter Four tables generated.")

# Workbook output is a convenience copy of the generated CSV tables, not an independent simulator.
# The source tables include reported reference values where first-principles parameters are absent.
with pd.ExcelWriter(out/'chapter4_results.xlsx',engine='openpyxl') as writer:
    for csv_path in sorted(out.glob('Table_4_*.csv')):
        pd.read_csv(csv_path).to_excel(writer,sheet_name=csv_path.stem.replace('Table_','T')[:31],index=False)
print('Workbook: outputs/tables/chapter4_results.xlsx')
