from common import ROOT
import pandas as pd
from cloud_migration.reporting_reproduction import reconstruct_all
from cloud_migration.plotting import plot_all
anchors=pd.read_csv(ROOT/"data/reference/scenario_anchors.csv")
monthly=reconstruct_all(anchors)
plot_all(monthly,pd.read_csv(ROOT/"data/workloads.csv"),anchors,pd.read_csv(ROOT/"data/reference/cost_drivers_reported.csv"),pd.read_csv(ROOT/"data/reference/elasticity_reported.csv"),pd.read_csv(ROOT/"data/reference/sensitivity_reported.csv"),ROOT/"outputs/figures")
print("Figures 4.1-4.6 generated as PNG and PDF.")
