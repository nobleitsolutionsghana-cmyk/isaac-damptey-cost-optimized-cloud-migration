"""Explicitly select thesis reporting reconstruction or first-principles mode."""
import argparse
import subprocess
import sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--mode',choices=['reported','first-principles'],default='reported')
p.add_argument('--scenario',choices=['baseline','hybrid','optimized'],default='optimized')
a=p.parse_args()
here=Path(__file__).resolve().parent
cmd=([sys.executable,str(here/'reproduce_reported_thesis.py')]
     if a.mode=='reported' else
     [sys.executable,str(here/'run_first_principles.py'),'--scenario',a.scenario])
raise SystemExit(subprocess.call(cmd))
