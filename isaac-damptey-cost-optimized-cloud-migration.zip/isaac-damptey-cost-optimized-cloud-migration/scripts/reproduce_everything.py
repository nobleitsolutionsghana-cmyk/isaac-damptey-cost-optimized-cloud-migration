from common import ROOT
import hashlib, json, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
import numpy, pandas, matplotlib
from cloud_migration.validation import build_validation_rows
from cloud_migration.validate_against_excel import audit_excel_formula_presence
from cloud_migration.simulation import run_first_principles
from cloud_migration.exceptions import ParameterResolutionError


def run(script):
    subprocess.run([sys.executable,str(ROOT/"scripts"/script)],check=True,cwd=ROOT)

run("reproduce_reported_thesis.py")
run("generate_tables.py")
run("generate_figures.py")
run("run_scalability_test.py")
validation=build_validation_rows(ROOT/"data/reference")
(ROOT/"outputs/validation").mkdir(parents=True,exist_ok=True)
validation.to_csv(ROOT/"outputs/validation/validation_results.csv",index=False)
critical=validation[validation.reproduction_basis.str.contains("Exact thesis-faithful|Derived from reconstructed",regex=True)]
critical_fail=critical[critical.status=="FAIL"]
# Strict first-principles audit
unresolved=[]
for scenario in ["baseline","hybrid","optimized"]:
    try:
        run_first_principles(ROOT/"data/workloads.csv",ROOT/"data/pricing.csv",ROOT/"config/base.yaml",ROOT/f"config/{scenario}.yaml")
    except ParameterResolutionError as exc:
        unresolved.extend(exc.missing)
# pytest
pytest_result=subprocess.run([sys.executable,"-m","pytest","-q"],cwd=ROOT,capture_output=True,text=True)
print(pytest_result.stdout); print(pytest_result.stderr,file=sys.stderr)
if pytest_result.returncode!=0:
    raise SystemExit(pytest_result.returncode)
excel_audit=audit_excel_formula_presence(ROOT/"validation/thesis_validation.xlsx")
if excel_audit.get("status") != "PASS":
    raise SystemExit(f"Excel validation workbook structural audit failed: {excel_audit}")

def _markdown_table(df):
    headers=[str(c) for c in df.columns]
    lines=["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"]*len(headers)) + " |"]
    for row in df.itertuples(index=False,name=None):
        vals=[]
        for v in row:
            if isinstance(v,float):
                vals.append(f"{v:.6g}")
            else:
                vals.append(str(v))
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)

# Human-readable validation evidence requested for examiner review.
validation_report = [
    "# Validation Report",
    "",
    "This report separates exact thesis-faithful reconstruction from independent first-principles execution. It does not claim that source parameters absent from the thesis were recovered or inferred.",
    "",
    f"**Thesis-faithful critical checks:** {'PASS' if critical_fail.empty else 'FAIL'}",
    f"**Excel formula-structure audit:** {excel_audit['status']} ({excel_audit['formula_cells']} formula cells detected)",
    f"**First-principles status:** {'BLOCKED BY UNRESOLVED SOURCE PARAMETERS' if unresolved else 'COMPLETE'}",
    "",
    "## Quantitative validation matrix",
    "",
    _markdown_table(validation),
    "",
    "## First-principles completeness",
    "",
]
if unresolved:
    validation_report += [
        "Exact first-principles reproduction is deliberately blocked until the following thesis source parameters are supplied:",
        "",
        *[f"- `{x}`" for x in sorted(set(unresolved))],
        "",
        "See `UNRESOLVED_REPRODUCIBILITY_ITEMS.md` for methodological consequences and required provenance.",
    ]
else:
    validation_report.append("All required first-principles inputs were resolved.")
(ROOT/"docs/VALIDATION_REPORT.md").write_text("\n".join(validation_report)+"\n",encoding="utf-8")

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for block in iter(lambda:f.read(65536),b""): h.update(block)
    return h.hexdigest()
inputs=[ROOT/"data/workloads.csv",ROOT/"data/pricing.csv",ROOT/"data/model_parameters.csv",ROOT/"data/sensitivity_parameters.csv",ROOT/"data/reference/scenario_anchors.csv"]
outputs=[p for p in (ROOT/"outputs").rglob("*") if p.is_file()]
manifest={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"python_version":platform.python_version(),"platform":platform.platform(),"numpy_version":numpy.__version__,"pandas_version":pandas.__version__,"matplotlib_version":matplotlib.__version__,"simulation_horizon_months":36,"execution_mode":"thesis-faithful reconstruction + strict first-principles completeness audit","validation_result":"PASS" if critical_fail.empty else "FAIL","first_principles_status":"BLOCKED_BY_UNRESOLVED_SOURCE_PARAMETERS" if unresolved else "COMPLETE","unresolved_parameters":sorted(set(unresolved)),"excel_formula_audit":excel_audit,"input_hashes":{str(p.relative_to(ROOT)):sha256(p) for p in inputs},"output_hashes":{str(p.relative_to(ROOT)):sha256(p) for p in outputs}}
(ROOT/"outputs/logs").mkdir(parents=True,exist_ok=True); (ROOT/"outputs/logs/run_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

source_files=list((ROOT/"src").rglob("*.py"))+list((ROOT/"scripts").glob("*.py"))
test_files=list((ROOT/"tests").glob("test_*.py"))
exact_rows=validation[validation.reproduction_basis.str.contains("Exact thesis-faithful",regex=False)]
derived_rows=validation[validation.reproduction_basis.str.contains("Derived from reconstructed",regex=False)]
independent_rows=validation[validation.reproduction_basis.str.contains("Independently derived",regex=False)]
self_audit=[
    "# Final Reproducibility Self-Audit",
    "",
    f"- Source-code files: **{len(source_files)}**",
    f"- Test files: **{len(test_files)}**",
    f"- Pytest result: **{pytest_result.stdout.strip()}**",
    f"- Exact thesis-faithful validation checks passed: **{int((exact_rows.status=='PASS').sum())}/{len(exact_rows)}**",
    f"- Derived-from-reconstructed validation checks passed: **{int((derived_rows.status=='PASS').sum())}/{len(derived_rows)}**",
    f"- Independently derived validation checks passed: **{int((independent_rows.status=='PASS').sum())}/{len(independent_rows)}**",
    f"- Excel validation workbook: **{excel_audit['status']}** with **{excel_audit['formula_cells']}** detected formula cells",
    f"- First-principles status: **{manifest['first_principles_status']}**",
    f"- Unresolved first-principles parameters: **{len(sorted(set(unresolved)))}**",
    "",
    "## Scientific-integrity conclusion",
    "",
    "The package supports exact thesis-faithful reproduction of the documented anchor-constrained monthly trajectories and their TCO/checkpoint constraints. It does not claim full first-principles reproduction because exact scenario/workload coefficients required by Equations 3.2-3.23 are not all preserved in the thesis source.",
    "",
    "The displayed TCO values imply Optimized-versus-Hybrid savings of USD 25,016.83, whereas the thesis table reports USD 25,016.84. This one-cent item is retained in the audit rather than concealed.",
]
(ROOT/"docs/FINAL_SELF_AUDIT.md").write_text("\n".join(self_audit)+"\n",encoding="utf-8")
print(json.dumps({k:manifest[k] for k in ["validation_result","first_principles_status","unresolved_parameters","excel_formula_audit"]},indent=2))
if not critical_fail.empty:
    print(critical_fail.to_string(index=False)); raise SystemExit(1)
print("Reproduction package completed. No claim of 100% first-principles reproducibility is made.")
