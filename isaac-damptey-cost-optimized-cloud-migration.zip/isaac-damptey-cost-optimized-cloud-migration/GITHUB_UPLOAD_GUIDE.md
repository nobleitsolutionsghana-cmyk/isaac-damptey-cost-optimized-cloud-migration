# GitHub upload and publication guide

## Browser upload (easiest)

1. Sign in to [GitHub](https://github.com).
2. Select **New repository**, name it `isaac-damptey-cost-optimized-cloud-migration`.
3. Add description: "Python code and transparent reproducibility materials for simulated cloud migration cost planning in public universities."
4. Choose Public only after reviewing thesis ownership, source-code licensing, project confidentiality and any university submission requirements.
5. Create the repository without adding a second README/licence (both exist in the ZIP).
6. Extract the ZIP and upload the **contents of the repository folder** in GitHub's **Add file → Upload files** view. Keep the `.github/workflows/tests.yml` file and the nested folder structure. GitHub browser uploads of many files can be cumbersome; Git CLI is preferable for the full folder tree.
7. Commit the files. Open **Actions** and check that tests pass.
8. Confirm the README shows both reproducibility modes and the first-principles parameter limitation.
9. Create a release using **Releases → Draft a new release**, tag `v1.0.0` *after independently verifying the run*. Attach the project ZIP to the release if desired.
10. Copy the real GitHub URL only after the repository is created. A Zenodo–GitHub integration can archive a release and issue a DOI; do not cite an unissued DOI.

## Git command-line method

Run from the extracted repository folder:

```bash
git init
git add .
git commit -m "Initial thesis code and reproducibility release"
git branch -M main
# Create the empty GitHub repository in the browser first, then use ITS actual URL:
git remote add origin https://github.com/ACCOUNT/isaac-damptey-cost-optimized-cloud-migration.git
git push -u origin main
```

`ACCOUNT` above is a documented command template, not an invented username or existing URL.

**Before publishing**, inspect every file including `legacy/` for copyright/confidentiality constraints. Since `legacy/appendix_a_transcribed.py` is sourced from the thesis document, its provenance should remain accurately described. Source-code MIT licence applies subject to the actual author/rightsholder's approval; it does not automatically license the thesis text or others' content.
